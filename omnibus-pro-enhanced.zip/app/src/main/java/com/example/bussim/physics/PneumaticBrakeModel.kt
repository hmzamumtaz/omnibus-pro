package com.example.bussim.physics

import kotlin.math.max
import kotlin.math.min

/**
 * Heavy-duty Commercial Vehicle Dual-Circuit Pneumatic Air Brake System,
 * Multi-Stage Jake Compression Brake, Trailer Supply Valve, and Rotor Thermal Fade.
 */
class PneumaticBrakeModel {
    // Dual air circuit pressures in Bar
    var tank1PressureBar: Float = 10.2f // Circuit 1 (Front service)
    var tank2PressureBar: Float = 10.2f // Circuit 2 (Rear service)
    var trailerTankPressureBar: Float = 10.0f // Trailer auxiliary reservoir

    var parkingBrakeEngaged: Boolean = true // Yellow diamond tractor valve
    var trailerSupplyValvePopped: Boolean = true // Red octagonal trailer valve

    var retarderLevel: Int = 0 // 0 = Off, 1..4 = Retarder stages
    var jakeBrakeStage: Int = 0 // 0 = Off, 1 = Low (2 cyl), 2 = Med (4 cyl), 3 = High (6 cyl)
    val jakeBrakeEnabled: Boolean
        get() = jakeBrakeStage > 0

    var isCompressorPumping: Boolean = false
    var hasPurgedAir: Boolean = false
    var isLowAirAlarmActive: Boolean = false

    // ABS Pulse state
    var isAbsActive: Boolean = false

    // Brake Rotor Temperature & Thermal Fade
    var rotorTempCelsius: Float = 45f
    var brakeFadeFactor: Float = 1.0f

    private val cutInPressureBar = 8.2f
    private val cutOutPressureBar = 10.5f

    fun update(
        dt: Float,
        brakePedalInput: Float,
        engineRpm: Float,
        isEngineRunning: Boolean,
        wheelSlipRatio: Float
    ): Float {
        // Air consumption by brake application
        if (brakePedalInput > 0.05f) {
            val airDrainRate = brakePedalInput * 0.48f * dt
            tank1PressureBar = max(0f, tank1PressureBar - airDrainRate)
            tank2PressureBar = max(0f, tank2PressureBar - airDrainRate)
            if (!trailerSupplyValvePopped) {
                trailerTankPressureBar = max(0f, trailerTankPressureBar - airDrainRate * 0.7f)
            }
        }

        // Rotor heating from friction braking
        if (brakePedalInput > 0.1f) {
            val heatingRate = brakePedalInput * 35f * dt
            rotorTempCelsius = min(750f, rotorTempCelsius + heatingRate)
        } else {
            // Ambient convective cooling
            val coolingRate = 2.5f * dt
            rotorTempCelsius = max(35f, rotorTempCelsius - coolingRate)
        }

        // Thermal fade coefficient
        brakeFadeFactor = if (rotorTempCelsius > 520f) {
            (1.0f - ((rotorTempCelsius - 520f) / 230f) * 0.45f).coerceIn(0.55f, 1.0f)
        } else {
            1.0f
        }

        // Compressor operation via engine auxiliary drive
        if (isEngineRunning) {
            if (tank1PressureBar < cutInPressureBar || tank2PressureBar < cutInPressureBar) {
                isCompressorPumping = true
            }

            if (isCompressorPumping) {
                val rechargeSpeed = (engineRpm / 1500f) * 0.35f * dt
                tank1PressureBar = min(cutOutPressureBar, tank1PressureBar + rechargeSpeed)
                tank2PressureBar = min(cutOutPressureBar, tank2PressureBar + rechargeSpeed)

                if (!trailerSupplyValvePopped) {
                    trailerTankPressureBar = min(cutOutPressureBar, trailerTankPressureBar + rechargeSpeed * 0.8f)
                }

                if (tank1PressureBar >= cutOutPressureBar && tank2PressureBar >= cutOutPressureBar) {
                    isCompressorPumping = false
                    hasPurgedAir = true // triggers air dryer release hiss
                }
            }
        }

        // Low pressure safety threshold (commercial vehicle standard 6.0 bar)
        isLowAirAlarmActive = (tank1PressureBar < 6.0f || tank2PressureBar < 6.0f)

        // Retarder braking torque (independent of friction brakes, no thermal fade)
        val retarderTorqueNm = when (retarderLevel) {
            1 -> 600f
            2 -> 1200f
            3 -> 1800f
            4 -> 2500f
            else -> 0f
        }

        // 3-Stage Jake Compression Brake on overrun
        val jakeBrakeTorqueNm = if (engineRpm > 1050f) {
            when (jakeBrakeStage) {
                1 -> 950f   // 2 cylinders
                2 -> 1900f  // 4 cylinders
                3 -> 2850f  // 6 cylinders full decompression
                else -> 0f
            }
        } else 0f

        // Mechanical service brake torque from air pressure and pedal modulation
        val availableAirFactor = (tank1PressureBar / 10.0f).coerceIn(0f, 1.2f)
        val serviceBrakeTorqueNm = brakePedalInput * 19000f * availableAirFactor * brakeFadeFactor

        // ABS intervention logic: prevent wheel lockup
        isAbsActive = (wheelSlipRatio < -0.18f && brakePedalInput > 0.3f)
        val modulatedServiceBrake = if (isAbsActive) serviceBrakeTorqueNm * 0.65f else serviceBrakeTorqueNm

        // Parking brake full lock (Tractor maxi spring brake + Trailer emergency spring brake)
        val totalBrakingTorque = if (parkingBrakeEngaged || trailerSupplyValvePopped) {
            42000f
        } else {
            modulatedServiceBrake + retarderTorqueNm + jakeBrakeTorqueNm
        }

        return totalBrakingTorque
    }

    fun cycleRetarder(): Int {
        retarderLevel = (retarderLevel + 1) % 5
        return retarderLevel
    }

    fun cycleJakeBrake(): Int {
        jakeBrakeStage = (jakeBrakeStage + 1) % 4
        return jakeBrakeStage
    }

    fun toggleParkingBrake(): Boolean {
        parkingBrakeEngaged = !parkingBrakeEngaged
        return parkingBrakeEngaged
    }

    fun toggleTrailerSupplyValve(): Boolean {
        trailerSupplyValvePopped = !trailerSupplyValvePopped
        return trailerSupplyValvePopped
    }
}
