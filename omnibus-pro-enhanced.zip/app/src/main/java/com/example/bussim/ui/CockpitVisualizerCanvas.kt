package com.example.bussim.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bussim.viewmodel.CameraView
import com.example.bussim.viewmodel.SimulatorUiState
import com.example.bussim.world.WeatherCondition
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun CockpitVisualizerCanvas(
    state: SimulatorUiState,
    modifier: Modifier = Modifier
) {
    val telemetry = state.telemetry
    val weather = state.weather
    val timeOfDay = state.timeOfDayHours

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(260.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Black)
            .testTag("simulator_canvas_viewport")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            when (state.cameraView) {
                CameraView.COCKPIT -> {
                    drawCockpitView(width, height, telemetry, weather, timeOfDay, state)
                }
                CameraView.CHASE_3D -> {
                    drawChaseView(width, height, telemetry, weather, timeOfDay, state)
                }
                CameraView.PASSENGER_CCTV -> {
                    drawPassengerCctvView(width, height, state)
                }
                CameraView.SUSPENSION_CHASSIS -> {
                    drawSuspensionChassisView(width, height, telemetry)
                }
            }
        }

        // Overlay camera label and destination sign
        Surface(
            color = Color(0xCC0A0E14),
            shape = RoundedCornerShape(bottomEnd = 8.dp),
            modifier = Modifier.align(Alignment.TopStart)
        ) {
            Text(
                text = "CAM: ${state.cameraView.name} | ${state.currentRoute?.routeNumber ?: "M42"} [${state.selectedBus?.matrixDestination ?: "EXPRESS"}]",
                color = Color(0xFF00E5FF),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }

        // Speed & Gear HUD watermark
        Surface(
            color = Color(0xAA000000),
            shape = RoundedCornerShape(bottomStart = 8.dp),
            modifier = Modifier.align(Alignment.TopEnd)
        ) {
            Text(
                text = "${telemetry.speedKmh.toInt()} KM/H | GEAR: ${if (telemetry.gearMode == "D") telemetry.currentGear.toString() else telemetry.gearMode}",
                color = Color(0xFFFFB300),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

// 1. Cockpit Driver View
private fun DrawScope.drawCockpitView(
    width: Float,
    height: Float,
    telemetry: com.example.bussim.physics.VehicleTelemetry,
    weather: WeatherCondition,
    timeOfDay: Float,
    state: SimulatorUiState
) {
    val horizonY = height * 0.45f + (telemetry.bodyPitchDeg * 4f)
    val rollAngle = telemetry.bodyRollDeg

    // 1. Sky with Time of Day gradient
    val (skyTop, skyBottom) = getSkyColors(timeOfDay, weather)
    drawRect(
        brush = Brush.verticalGradient(listOf(skyTop, skyBottom), 0f, horizonY),
        size = Size(width, horizonY)
    )

    // 2. Mountains / City skyline in background
    drawSkyline(width, horizonY, timeOfDay)

    // 3. Ground / Road perspective
    drawRect(
        color = Color(0xFF1E242C),
        topLeft = Offset(0f, horizonY),
        size = Size(width, height - horizonY)
    )

    // 3D Perspective Road
    val roadTopWidth = width * 0.16f
    val roadBottomWidth = width * 1.35f
    val centerX = width * 0.5f - (telemetry.lateralG * 60f)

    val roadPath = Path().apply {
        moveTo(centerX - roadTopWidth / 2, horizonY)
        lineTo(centerX + roadTopWidth / 2, horizonY)
        lineTo(centerX + roadBottomWidth / 2, height)
        lineTo(centerX - roadBottomWidth / 2, height)
        close()
    }
    drawPath(roadPath, color = Color(0xFF28313D))

    // Road shoulders
    drawLine(
        color = Color(0xFFFFCC00),
        start = Offset(centerX - roadTopWidth / 2, horizonY),
        end = Offset(centerX - roadBottomWidth / 2, height),
        strokeWidth = 3f
    )
    drawLine(
        color = Color.White,
        start = Offset(centerX + roadTopWidth / 2, horizonY),
        end = Offset(centerX + roadBottomWidth / 2, height),
        strokeWidth = 3f
    )

    // Animated dashed center lane lines
    val animOffset = (telemetry.distanceDrivenMeters % 10f) / 10f
    for (i in 1..8) {
        val t1 = ((i - 1 + animOffset) / 8f).coerceIn(0f, 1f)
        val t2 = ((i - 0.5f + animOffset) / 8f).coerceIn(0f, 1f)
        val y1 = horizonY + (height - horizonY) * (t1 * t1)
        val y2 = horizonY + (height - horizonY) * (t2 * t2)
        drawLine(
            color = Color.White.copy(alpha = 0.85f),
            start = Offset(centerX, y1),
            end = Offset(centerX, y2),
            strokeWidth = 2f + t2 * 5f
        )
    }

    // AI Traffic Vehicles in front
    state.trafficVehicles.filter { it.relativeDistanceM in 10f..250f }.forEach { v ->
        val normDist = (1f - (v.relativeDistanceM / 250f)).coerceIn(0.05f, 1f)
        val vY = horizonY + (height - horizonY) * (normDist * normDist * 0.82f)
        val vScale = normDist * normDist * 40f
        val vX = centerX + (v.laneIndex * width * 0.18f * normDist)

        val carColor = try { Color(android.graphics.Color.parseColor(v.colorHex)) } catch (e: Exception) { Color.Cyan }
        drawRect(
            color = carColor,
            topLeft = Offset(vX - vScale * 0.8f, vY - vScale * 0.6f),
            size = Size(vScale * 1.6f, vScale * 0.8f)
        )
        // Taillights
        drawCircle(Color.Red, radius = vScale * 0.15f, center = Offset(vX - vScale * 0.55f, vY))
        drawCircle(Color.Red, radius = vScale * 0.15f, center = Offset(vX + vScale * 0.55f, vY))
    }

    // Cockpit Window Frame & Steering Wheel overlay
    drawCockpitInteriorFrame(width, height, telemetry)

    // Weather particles (Rain / Snow) & Wipers
    if (weather.isRaining || weather.isSnowing) {
        drawPrecipitationAndWipers(width, height, weather, state.telemetry)
    }
}

// 2. Exterior Chase View
private fun DrawScope.drawChaseView(
    width: Float,
    height: Float,
    telemetry: com.example.bussim.physics.VehicleTelemetry,
    weather: WeatherCondition,
    timeOfDay: Float,
    state: SimulatorUiState
) {
    val horizonY = height * 0.50f
    val (skyTop, skyBottom) = getSkyColors(timeOfDay, weather)
    drawRect(
        brush = Brush.verticalGradient(listOf(skyTop, skyBottom), 0f, horizonY),
        size = Size(width, horizonY)
    )
    drawRect(
        color = Color(0xFF1E242C),
        topLeft = Offset(0f, horizonY),
        size = Size(width, height - horizonY)
    )

    // Road
    val centerX = width * 0.5f
    val roadPath = Path().apply {
        moveTo(centerX - width * 0.2f, horizonY)
        lineTo(centerX + width * 0.2f, horizonY)
        lineTo(centerX + width * 0.6f, height)
        lineTo(centerX - width * 0.6f, height)
        close()
    }
    drawPath(roadPath, Color(0xFF28313D))

    val isTruck = telemetry.vehicleCategory == com.example.bussim.physics.VehicleCategory.HEAVY_TRUCK_SEMI

    if (isTruck) {
        // Semi-Trailer rendering with 5th wheel kingpin articulation
        val trailerWidth = width * 0.34f
        val trailerHeight = height * 0.44f
        val trailerOffset = telemetry.trailerArticulationDeg * 2.2f
        val trailerX = centerX - trailerWidth / 2 - (telemetry.lateralG * 25f) + trailerOffset
        val trailerY = height * 0.42f + (telemetry.bodyPitchDeg * 2.0f)

        // Semi-trailer box
        drawRoundRect(
            color = Color(0xFFCFD8DC),
            topLeft = Offset(trailerX, trailerY),
            size = Size(trailerWidth, trailerHeight - 15f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
        )
        // Trailer door split line & refrigeration unit
        drawLine(Color(0xFF546E7A), Offset(trailerX + trailerWidth / 2, trailerY), Offset(trailerX + trailerWidth / 2, trailerY + trailerHeight - 15f), 2f)
        drawRect(Color(0xFF263238), topLeft = Offset(trailerX + trailerWidth * 0.35f, trailerY - 8f), size = Size(trailerWidth * 0.3f, 8f))

        // Triple axle trailer wheels
        for (axle in 0..2) {
            val axleOffset = axle * 14f
            drawRoundRect(Color(0xFF111111), Offset(trailerX + 6f, trailerY + trailerHeight - 24f - axleOffset), Size(16f, 22f), androidx.compose.ui.geometry.CornerRadius(3f, 3f))
            drawRoundRect(Color(0xFF111111), Offset(trailerX + trailerWidth - 22f, trailerY + trailerHeight - 24f - axleOffset), Size(16f, 22f), androidx.compose.ui.geometry.CornerRadius(3f, 3f))
        }

        // Taillights
        val isBraking = telemetry.speedMs > 0.1f && telemetry.longitudinalG < -0.1f
        val lightColor = if (isBraking) Color(0xFFFF1744) else Color(0xFFD50000)
        drawRect(lightColor, topLeft = Offset(trailerX + 8f, trailerY + trailerHeight * 0.75f), size = Size(10f, 18f))
        drawRect(lightColor, topLeft = Offset(trailerX + trailerWidth - 18f, trailerY + trailerHeight * 0.75f), size = Size(10f, 18f))
    } else {
        // Transit Bus Body
        val busWidth = width * 0.32f
        val busHeight = height * 0.40f
        val busX = centerX - busWidth / 2 - (telemetry.lateralG * 35f)
        val busY = height * 0.46f + (telemetry.bodyPitchDeg * 2.5f)

        val busColor = try {
            Color(android.graphics.Color.parseColor(state.selectedBus?.paintColorHex ?: "#00E5FF"))
        } catch (e: Exception) {
            Color(0xFF00E5FF)
        }

        // Bus shadow
        drawOval(
            color = Color(0x66000000),
            topLeft = Offset(busX - 10f, busY + busHeight - 10f),
            size = Size(busWidth + 20f, 24f)
        )

        // Bus Main Body Box
        drawRoundRect(
            color = busColor,
            topLeft = Offset(busX, busY),
            size = Size(busWidth, busHeight - 12f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
        )

        // Rear Windshield
        drawRect(
            color = Color(0xFF152230),
            topLeft = Offset(busX + 16f, busY + 22f),
            size = Size(busWidth - 32f, busHeight * 0.38f)
        )

        // LED Destination Sign at Top
        drawRect(
            color = Color(0xFF050505),
            topLeft = Offset(busX + 24f, busY + 6f),
            size = Size(busWidth - 48f, 12f)
        )
        drawRect(
            color = Color(0xFFFFB300),
            topLeft = Offset(busX + 30f, busY + 9f),
            size = Size(busWidth - 60f, 6f)
        )

        // Taillights
        val isBraking = telemetry.speedMs > 0.1f && telemetry.longitudinalG < -0.1f
        val lightColor = if (isBraking) Color(0xFFFF1744) else Color(0xFFD50000)
        drawRect(lightColor, topLeft = Offset(busX + 8f, busY + busHeight * 0.65f), size = Size(10f, 22f))
        drawRect(lightColor, topLeft = Offset(busX + busWidth - 18f, busY + busHeight * 0.65f), size = Size(10f, 22f))

        // Dual Commercial Wheels
        drawRoundRect(
            color = Color(0xFF111111),
            topLeft = Offset(busX + 6f, busY + busHeight - 20f),
            size = Size(18f, 26f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
        )
        drawRoundRect(
            color = Color(0xFF111111),
            topLeft = Offset(busX + busWidth - 24f, busY + busHeight - 20f),
            size = Size(18f, 26f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
        )
    }
}

// 3. Passenger CCTV View
private fun DrawScope.drawPassengerCctvView(width: Float, height: Float, state: SimulatorUiState) {
    // CCTV scanlines background
    drawRect(color = Color(0xFF0A141A), size = Size(width, height))

    // Cabin Perspective
    val aisleLeft = width * 0.38f
    val aisleRight = width * 0.62f
    drawLine(Color(0xFF2C3E50), Offset(0f, 0f), Offset(aisleLeft, height), 2f)
    drawLine(Color(0xFF2C3E50), Offset(width, 0f), Offset(aisleRight, height), 2f)

    // Floor
    drawRect(Color(0xFF1C2B36), topLeft = Offset(aisleLeft, 0f), size = Size(aisleRight - aisleLeft, height))

    // Seated passenger dots & indicators
    state.activePassengers.take(12).forEachIndexed { index, p ->
        val isLeft = index % 2 == 0
        val rowY = height * 0.22f + (index / 2) * (height * 0.12f)
        val seatX = if (isLeft) width * 0.22f else width * 0.78f

        // Passenger silhouette
        val moodColor = when {
            p.satisfactionPercent > 85f -> Color(0xFF00E676)
            p.satisfactionPercent > 60f -> Color(0xFFFFB300)
            else -> Color(0xFFFF3D00)
        }
        drawCircle(color = moodColor, radius = 9f, center = Offset(seatX, rowY))
        drawRect(color = Color(0xFF37474F), topLeft = Offset(seatX - 10f, rowY + 9f), size = Size(20f, 14f))

        // Speech bubble dot indicator if speaking
        if (p.currentSpeechBubble != null) {
            drawCircle(Color.White, radius = 4f, center = Offset(seatX + 12f, rowY - 8f))
        }
    }

    // CCTV Timestamp HUD
    drawCircle(Color.Red, radius = 4f, center = Offset(24f, 24f))
}

// 4. Suspension & Chassis Telemetry Cam
private fun DrawScope.drawSuspensionChassisView(
    width: Float,
    height: Float,
    telemetry: com.example.bussim.physics.VehicleTelemetry
) {
    drawRect(color = Color(0xFF090D12), size = Size(width, height))

    // Chassis frame rails
    val frameTop = height * 0.25f
    val frameBottom = height * 0.75f
    val frameLeft = width * 0.32f
    val frameRight = width * 0.68f

    // Heavy steel frame rails
    drawLine(Color(0xFF546E7A), Offset(frameLeft, frameTop), Offset(frameLeft, frameBottom), 8f)
    drawLine(Color(0xFF546E7A), Offset(frameRight, frameTop), Offset(frameRight, frameBottom), 8f)
    // Cross members
    drawLine(Color(0xFF455A64), Offset(frameLeft, height * 0.35f), Offset(frameRight, height * 0.35f), 5f)
    drawLine(Color(0xFF455A64), Offset(frameLeft, height * 0.65f), Offset(frameRight, height * 0.65f), 5f)

    // Air bellows / Springs
    val corners = listOf(
        Pair(frameLeft - 40f, height * 0.32f),  // Front Left
        Pair(frameRight + 40f, height * 0.32f), // Front Right
        Pair(frameLeft - 40f, height * 0.68f),  // Rear Left
        Pair(frameRight + 40f, height * 0.68f)  // Rear Right
    )

    corners.forEachIndexed { i, pos ->
        val (cx, cy) = pos
        // Air bag bellow
        val isRight = i % 2 == 1
        val kneelDisp = if (telemetry.isKneeling && isRight) 14f else 0f
        drawOval(
            color = Color(0xFF00E5FF),
            topLeft = Offset(cx - 16f, cy - 10f + kneelDisp),
            size = Size(32f, 20f)
        )
        // Tire
        drawRoundRect(
            color = if (telemetry.isHydroplaning) Color(0xFFFF1744) else Color(0xFF263238),
            topLeft = Offset(cx - 8f, cy - 24f),
            size = Size(16f, 48f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
        )
    }
}

private fun DrawScope.drawCockpitInteriorFrame(
    width: Float,
    height: Float,
    telemetry: com.example.bussim.physics.VehicleTelemetry
) {
    // Left A-Pillar
    val leftPillar = Path().apply {
        moveTo(0f, 0f)
        lineTo(width * 0.14f, 0f)
        lineTo(width * 0.08f, height)
        lineTo(0f, height)
        close()
    }
    drawPath(leftPillar, Color(0xFF111822))

    // Right A-Pillar
    val rightPillar = Path().apply {
        moveTo(width * 0.86f, 0f)
        lineTo(width, 0f)
        lineTo(width, height)
        lineTo(width * 0.92f, height)
        close()
    }
    drawPath(rightPillar, Color(0xFF111822))

    // Top Header & Sun Blind
    drawRect(Color(0xFF16202E), topLeft = Offset(0f, 0f), size = Size(width, 24f))

    // Dashboard Bumper
    val dashY = height * 0.78f + (telemetry.bodyPitchDeg * 2f)
    drawRect(
        brush = Brush.verticalGradient(listOf(Color(0xFF141C26), Color(0xFF0C1017)), dashY, height),
        topLeft = Offset(0f, dashY),
        size = Size(width, height - dashY)
    )

    // Steering wheel rim rotating
    val wheelCenterX = width * 0.32f
    val wheelCenterY = height * 0.92f
    val steerAngleRad = (telemetry.lateralG * 1.5f).coerceIn(-1.2f, 1.2f)

    drawCircle(
        color = Color(0xFF212C3D),
        radius = 56f,
        center = Offset(wheelCenterX, wheelCenterY),
        style = Stroke(width = 12f)
    )
    // Steering crossbar
    val p1 = Offset(wheelCenterX + 48f * cos(steerAngleRad), wheelCenterY + 48f * sin(steerAngleRad))
    val p2 = Offset(wheelCenterX - 48f * cos(steerAngleRad), wheelCenterY - 48f * sin(steerAngleRad))
    drawLine(Color(0xFF37474F), p1, p2, 8f)
}

private fun DrawScope.drawPrecipitationAndWipers(
    width: Float,
    height: Float,
    weather: WeatherCondition,
    telemetry: com.example.bussim.physics.VehicleTelemetry
) {
    // Rain streaks / Snow dots
    val random = Random(42)
    val dropCount = if (weather.isSnowing) 60 else 90
    for (i in 0 until dropCount) {
        val rx = random.nextFloat() * width
        val ry = random.nextFloat() * height * 0.8f
        if (weather.isSnowing) {
            drawCircle(Color.White.copy(alpha = 0.75f), radius = 2.5f, center = Offset(rx, ry))
        } else {
            drawLine(
                color = Color(0x99B0BEC5),
                start = Offset(rx, ry),
                end = Offset(rx - 4f, ry + 16f),
                strokeWidth = 1.5f
            )
        }
    }
}

private fun DrawScope.drawSkyline(width: Float, horizonY: Float, timeOfDay: Float) {
    val skylineColor = if (timeOfDay in 6f..19f) Color(0xFF334155) else Color(0xFF111827)
    val path = Path().apply {
        moveTo(0f, horizonY)
        lineTo(width * 0.1f, horizonY - 25f)
        lineTo(width * 0.18f, horizonY - 10f)
        lineTo(width * 0.28f, horizonY - 45f)
        lineTo(width * 0.38f, horizonY - 15f)
        lineTo(width * 0.52f, horizonY - 55f)
        lineTo(width * 0.65f, horizonY - 20f)
        lineTo(width * 0.78f, horizonY - 40f)
        lineTo(width * 0.88f, horizonY - 18f)
        lineTo(width, horizonY)
        close()
    }
    drawPath(path, skylineColor)
}

private fun getSkyColors(timeOfDay: Float, weather: WeatherCondition): Pair<Color, Color> {
    if (weather == WeatherCondition.FOGGY_VALLEY) {
        return Pair(Color(0xFF78909C), Color(0xFFB0BEC5))
    }
    return when {
        timeOfDay in 6f..8f -> Pair(Color(0xFF2C3E50), Color(0xFFFF7043)) // Sunrise
        timeOfDay in 8f..17f -> Pair(Color(0xFF1E88E5), Color(0xFF90CAF9)) // Noon Blue
        timeOfDay in 17f..19.5f -> Pair(Color(0xFF311B92), Color(0xFFFF5722)) // Sunset
        else -> Pair(Color(0xFF030712), Color(0xFF0F172A)) // Night Sky
    }
}
