package com.example.bussim.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bussim.physics.PacejkaTireModel
import com.example.bussim.physics.VehicleCategory
import com.example.bussim.viewmodel.BusSimulatorViewModel
import com.example.bussim.viewmodel.SimulatorUiState
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun PhysicsDynoLabScreen(
    viewModel: BusSimulatorViewModel,
    state: SimulatorUiState,
    modifier: Modifier = Modifier
) {
    val telemetry = state.telemetry
    val suspension = viewModel.physicsEngine.suspension
    val drivetrain = viewModel.physicsEngine.drivetrain

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp)
            .testTag("physics_dyno_lab_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Vehicle Class Toggle (Transit Bus vs Heavy Truck 6x4)
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101722)),
                border = BorderStroke(1.dp, Color(0xFF233247)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "SIMULATION PLATFORM",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF90A4AE)
                        )
                        Text(
                            text = telemetry.vehicleCategory.displayName,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (telemetry.vehicleCategory == VehicleCategory.HEAVY_TRUCK_SEMI) Color(0xFFFFB300) else Color(0xFF00E5FF)
                        )
                        Text(
                            text = "GCW: ${(telemetry.totalWeightKg / 1000f).toInt()} Tons • Trans: ${drivetrain.transmissionType.displayName}",
                            fontSize = 11.sp,
                            color = Color(0xFF90A4AE)
                        )
                    }

                    Button(
                        onClick = { viewModel.toggleVehicleCategory() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (telemetry.vehicleCategory == VehicleCategory.HEAVY_TRUCK_SEMI) Color(0xFFFFB300) else Color(0xFF00E5FF)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("btn_toggle_vehicle_class")
                    ) {
                        Text(
                            text = if (telemetry.vehicleCategory == VehicleCategory.HEAVY_TRUCK_SEMI) "SWITCH TO BUS" else "SWITCH TO TRUCK",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // 2. Real-Time Pacejka '02 Magic Formula Oscilloscope Graph
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1118)),
                border = BorderStroke(1.dp, Color(0xFF1D2838)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Timeline, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "PACEJKA '02 MAGIC FORMULA (Fy vs α)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00E5FF)
                            )
                        }
                        Text(
                            text = "Grip μ: ${state.weather.surfaceType.frictionCoefficient}",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFFFB300)
                        )
                    }

                    // Canvas Graph
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF06090D))
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height
                            val midY = h / 2f
                            val midX = w / 2f

                            // Axes
                            drawLine(Color(0xFF2C3E55), Offset(0f, midY), Offset(w, midY), 1f)
                            drawLine(Color(0xFF2C3E55), Offset(midX, 0f), Offset(midX, h), 1f)

                            // Plot Pacejka curve from -0.35 rad to +0.35 rad
                            val path = Path()
                            val normalLoad = telemetry.totalWeightKg * 9.81f * 0.35f
                            val b = 10.0f
                            val c = 1.30f
                            val d = state.weather.surfaceType.frictionCoefficient * normalLoad
                            val e = -0.95f

                            var isFirst = true
                            for (xPixel in 0..w.toInt() step 4) {
                                val slipAngle = ((xPixel - midX) / midX) * 0.35f
                                val fy = PacejkaTireModel.magicFormula(slipAngle, b, c, d, e)
                                val yPixel = midY - (fy / (d * 1.25f)) * (h * 0.45f)

                                if (isFirst) {
                                    path.moveTo(xPixel.toFloat(), yPixel)
                                    isFirst = false
                                } else {
                                    path.lineTo(xPixel.toFloat(), yPixel)
                                }
                            }
                            drawPath(path, Color(0xFF00E5FF), style = Stroke(width = 3f))

                            // Live operating point cursor
                            val currentSlip = (telemetry.lateralG * 0.22f).coerceIn(-0.35f, 0.35f)
                            val liveFy = PacejkaTireModel.magicFormula(currentSlip, b, c, d, e)
                            val cursorX = midX + (currentSlip / 0.35f) * midX
                            val cursorY = midY - (liveFy / (d * 1.25f)) * (h * 0.45f)

                            drawCircle(Color(0xFFFFB300), radius = 6f, center = Offset(cursorX, cursorY))
                            drawCircle(Color.White, radius = 2.5f, center = Offset(cursorX, cursorY))
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Peak Lateral Grip D: ${(state.weather.surfaceType.frictionCoefficient * telemetry.totalWeightKg * 9.81f * 0.35f / 1000f).toInt()} kN",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color.White
                        )
                        Text(
                            text = "Live Lat G: ${"%.2f".format(telemetry.lateralG)}G",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFFFB300)
                        )
                    }
                }
            }
        }

        // 3. Engine Dynamometer Power & Torque Curve
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1118)),
                border = BorderStroke(1.dp, Color(0xFF1D2838)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Speed, contentDescription = null, tint = Color(0xFF00E676), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ENGINE DYNAMOMETER (HP & Nm vs RPM)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00E676)
                            )
                        }
                        Text(
                            text = "${telemetry.engineRpm.toInt()} RPM",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF00E5FF)
                        )
                    }

                    // Dyno Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF06090D))
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            // Torque curve (Cyan) and Horsepower curve (Amber)
                            val torquePath = Path()
                            val hpPath = Path()
                            val maxRpm = drivetrain.powertrainType.maxRpm

                            var isFirst = true
                            for (xPixel in 0..w.toInt() step 6) {
                                val rpm = (xPixel / w) * maxRpm
                                val tqNorm = when {
                                    rpm < 900f -> 0.5f + (rpm / 900f) * 0.4f
                                    rpm in 900f..1500f -> 0.98f
                                    else -> (0.98f - ((rpm - 1500f) / maxRpm) * 0.65f).coerceAtLeast(0.3f)
                                }
                                val hpNorm = ((rpm / maxRpm) * tqNorm * 1.1f).coerceIn(0f, 1f)

                                val yTq = h - tqNorm * (h * 0.85f)
                                val yHp = h - hpNorm * (h * 0.85f)

                                if (isFirst) {
                                    torquePath.moveTo(xPixel.toFloat(), yTq)
                                    hpPath.moveTo(xPixel.toFloat(), yHp)
                                    isFirst = false
                                } else {
                                    torquePath.lineTo(xPixel.toFloat(), yTq)
                                    hpPath.lineTo(xPixel.toFloat(), yHp)
                                }
                            }

                            drawPath(torquePath, Color(0xFF00E5FF), style = Stroke(width = 2.5f))
                            drawPath(hpPath, Color(0xFFFFB300), style = Stroke(width = 2.5f))

                            // Current RPM vertical line cursor
                            val currentRpmX = (telemetry.engineRpm / maxRpm).coerceIn(0f, 1f) * w
                            drawLine(Color.White.copy(alpha = 0.8f), Offset(currentRpmX, 0f), Offset(currentRpmX, h), 2f)
                            drawCircle(Color(0xFF00E676), radius = 5f, center = Offset(currentRpmX, h * 0.35f))
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Torque: ${telemetry.engineTorqueNm.toInt()} Nm",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF00E5FF),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Power: ${telemetry.engineHorsepower.toInt()} HP",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFFFB300),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Boost: ${"%.1f".format(telemetry.turboBoostBar)} bar",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF00E676)
                        )
                    }
                }
            }
        }

        // 4. Air Suspension & ECAS 4-Corner Telemetry
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101722)),
                border = BorderStroke(1.dp, Color(0xFF233247)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "MULTI-LINK AIR SUSPENSION & BELLOWS DISPLACEMENT",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF90A4AE)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CornerSuspensionPillar("Front Left (FL)", suspension.frontLeft.displacementMm, suspension.frontLeft.bagPressureBar, Modifier.weight(1f))
                        CornerSuspensionPillar("Front Right (FR)", suspension.frontRight.displacementMm, suspension.frontRight.bagPressureBar, Modifier.weight(1f))
                        CornerSuspensionPillar("Rear Left (RL)", suspension.rearLeft.displacementMm, suspension.rearLeft.bagPressureBar, Modifier.weight(1f))
                        CornerSuspensionPillar("Rear Right (RR)", suspension.rearRight.displacementMm, suspension.rearRight.bagPressureBar, Modifier.weight(1f))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Body Roll: ${"%.1f".format(telemetry.bodyRollDeg)}° | Pitch: ${"%.1f".format(telemetry.bodyPitchDeg)}°",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color.White
                        )
                        Text(
                            text = "Frame Torsion: ${"%.1f".format(telemetry.frameTwistDeg)}°",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF00E5FF)
                        )
                    }
                }
            }
        }

        // 5. Heavy Truck Semi-Trailer 5th Wheel Articulation & Jackknife Meter
        if (telemetry.vehicleCategory == VehicleCategory.HEAVY_TRUCK_SEMI) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (telemetry.isJackknifed) Color(0xFF330B0B) else Color(0xFF101722)
                    ),
                    border = BorderStroke(1.dp, if (telemetry.isJackknifed) Color.Red else Color(0xFF233247)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "5th WHEEL KINGPIN ARTICULATION",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (telemetry.isJackknifed) Color.Red else Color(0xFF90A4AE)
                            )
                            if (telemetry.isJackknifed) {
                                Surface(color = Color.Red, shape = RoundedCornerShape(4.dp)) {
                                    Text(
                                        text = "JACKKNIFE ALARM",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Text(
                            text = "Articulation Angle: ${"%.1f".format(telemetry.trailerArticulationDeg)}° (Limit: ±42°)",
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (abs(telemetry.trailerArticulationDeg) > 30f) Color(0xFFFFB300) else Color.White
                        )

                        // Articulation Bar
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(12.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF233247))
                        ) {
                            val normArt = ((telemetry.trailerArticulationDeg + 45f) / 90f).coerceIn(0f, 1f)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(normArt)
                                    .height(12.dp)
                                    .background(if (telemetry.isJackknifed) Color.Red else Color(0xFF00E5FF))
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Tractor-Trailer Protection: ${if (telemetry.trailerSupplyValvePopped) "POPPED (Emergency Lock)" else "CHARGED"}", fontSize = 10.sp, color = Color(0xFF90A4AE))
                            Text(text = "Inter-Axle Diff: ${if (telemetry.isDiffLocked) "LOCKED" else "OPEN"}", fontSize = 10.sp, color = Color(0xFF00E676))
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun CornerSuspensionPillar(
    cornerName: String,
    dispMm: Float,
    pressureBar: Float,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFF141C28),
        border = BorderStroke(1.dp, Color(0xFF253448)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(text = cornerName.take(2), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00E5FF))
            Text(
                text = "${dispMm.toInt()}mm",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = if (dispMm < -30f) Color(0xFFFFB300) else Color.White
            )
            Text(
                text = "${"%.1f".format(pressureBar)}b",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF90A4AE)
            )
        }
    }
}
