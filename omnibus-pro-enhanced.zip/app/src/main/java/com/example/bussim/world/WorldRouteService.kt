package com.example.bussim.world

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class WorldRouteResult(
    val distanceMeters: Double,
    val durationSeconds: Double,
    val geometry: List<Pair<Double, Double>> // latitude, longitude
)

class WorldRouteService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    suspend fun route(origin: WorldCity, destination: WorldCity): Result<WorldRouteResult> =
        withContext(Dispatchers.IO) {
            runCatching {
                val url = "https://router.project-osrm.org/route/v1/driving/" +
                    "${origin.longitude},${origin.latitude};${destination.longitude},${destination.latitude}" +
                    "?overview=full&geometries=geojson&steps=false"
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "OmnibusPro/1.0")
                    .build()

                client.newCall(request).execute().use { response ->
                    check(response.isSuccessful) { "Routing service returned ${response.code}" }
                    val body = response.body?.string().orEmpty()
                    val root = JSONObject(body)
                    val route = root.getJSONArray("routes").getJSONObject(0)
                    val geometry = route.getJSONObject("geometry").getJSONArray("coordinates")
                    val points = buildList {
                        for (i in 0 until geometry.length()) {
                            val p = geometry.getJSONArray(i)
                            add(p.getDouble(1) to p.getDouble(0))
                        }
                    }
                    WorldRouteResult(
                        distanceMeters = route.getDouble("distance"),
                        durationSeconds = route.getDouble("duration"),
                        geometry = points
                    )
                }
            }
        }
}