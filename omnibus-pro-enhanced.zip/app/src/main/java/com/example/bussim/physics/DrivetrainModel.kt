package com.example.bussim.physics

import kotlin.math.max
import kotlin.math.min

enum class PowertrainType(val displayName: String, val maxRpm: Float, val idleRpm: Float, val peakHp: Int, val peakTorqueNm: Int) {
    DIESEL("12.8L Turbo Diesel", 2200f, 600f, 480, 2300),
    ELECTRIC("Dual-Motor EV (550kW)", 10500f, 0f, 740, 3200),
    HYBRID("Parallel Hybrid Eco", 3200f, 650f, 390, 1900),
    CNG("Turbo CNG Euro VI", 2400f, 650f, 340, 1500),
    HEAVY_TRUCK_DIESEL("15.0L Cummins X15 Diesel", 2100f, 550f, 605, 2780)
}

enum class TransmissionType(val displayName: String, val gearCount: Int) {
    AUTOMATIC_ZF("ZF EcoLife 6-Speed Auto", 6),
    MANUAL_6("6-Speed Manual with Clutch", 6),
    TRAXON_AMT("TraXon 12-Speed AMT", 12),
    EATON_FULLER_18("Eaton Fuller 18-Speed Roadranger", 18)
}

class DrivetrainModel(
    var powertrainType: PowertrainType = PowertrainType.DIESEL,
    var transmissionType: TransmissionType = TransmissionType.AUTOMATIC_ZF
) {
    // Gear ratios for 6-speed ZF bus transmission
    val gearRatios6 = floatArrayOf(3.40f, 2.00f, 1.42f, 1.00f, 0.72f, 0.59f)

    // Eaton Fuller 18-speed ratios (Lo-L, Lo-H, 1L, 1H, 2L, 2H, 3L, 3H, 4L, 4H, 5L, 5H, 6L, 6H, 7L, 7H, 8L, 8H)
    val gearRatios18 = floatArrayOf(
        14.40f, 12.29f, 8.51f, 7.26f, 6.05f, 5.16f, 4.38f, 3.74f,
        3.20f, 2.73f, 2.29f, 1.95f, 1.62f, 1.38f, 1.17f, 1.00f, 0.86f, 0.73f
    )

    val reverseRatio = 3.65f
    val finalDriveRatio = 3.42f

    var engineRpm: Float = powertrainType.idleRpm
    var currentGear: Int = 1 // 1..18, 0 = Neutral, -1 = Reverse
    var gearMode: String = "D" // P, R, N, D, 1, 2, 3
    var turboBoostBar: Float = 0f
    var clutchEngagement: Float = 1.0f // 0.0 = pressed, 1.0 = engaged
    var isEngineRunning: Boolean = true
    var isShifting: Boolean = false
    var shiftTimerSec: Float = 0f

    // Heavy Truck Eaton Fuller 18-speed controls
    var isHighRange: Boolean = false // Low Range (1-4) vs High Range (5-8)
    var isSplitterHigh: Boolean = false // Direct vs Overdrive split

    // Inter-Axle Differential Lock (Tandem 6x4 drive axles)
    var isInterAxleDiffLocked: Boolean = false

    // Battery / Fuel state
    var batterySocPercent: Float = 95f
    var fuelTankPercent: Float = 88f

    fun calculateTorque(throttleInput: Float, dt: Float): Float {
        if (!isEngineRunning) return 0f

        val effectiveThrottle = throttleInput.coerceIn(0f, 1f)

        return when (powertrainType) {
            PowertrainType.DIESEL -> {
                val targetBoost = effectiveThrottle * 2.4f
                turboBoostBar += (targetBoost - turboBoostBar) * (dt * 3.5f)
                val baseTorque = when {
                    engineRpm < 900f -> 1200f + (engineRpm - 600f) * 1.5f
                    engineRpm in 900f..1400f -> 2300f
                    engineRpm in 1400f..1900f -> 2300f - (engineRpm - 1400f) * 1.1f
                    else -> max(600f, 1750f - (engineRpm - 1900f) * 3.5f)
                }
                (baseTorque * effectiveThrottle) * (0.6f + 0.4f * (turboBoostBar / 2.4f))
            }
            PowertrainType.HEAVY_TRUCK_DIESEL -> {
                val targetBoost = effectiveThrottle * 2.8f
                turboBoostBar += (targetBoost - turboBoostBar) * (dt * 3.0f)
                val baseTorque = when {
                    engineRpm < 850f -> 1400f + (engineRpm - 550f) * 2.0f
                    engineRpm in 850f..1400f -> 2780f
                    engineRpm in 1400f..1800f -> 2780f - (engineRpm - 1400f) * 1.4f
                    else -> max(800f, 2220f - (engineRpm - 1800f) * 4.0f)
                }
                (baseTorque * effectiveThrottle) * (0.55f + 0.45f * (turboBoostBar / 2.8f))
            }
            PowertrainType.ELECTRIC -> {
                val baseTorque = if (engineRpm < 4500f) 3200f else 3200f * (4500f / engineRpm)
                baseTorque * effectiveThrottle
            }
            PowertrainType.HYBRID -> {
                val combustionTorque = 1400f * effectiveThrottle
                val electricTorque = 900f * effectiveThrottle
                combustionTorque + electricTorque
            }
            PowertrainType.CNG -> {
                val baseTorque = when {
                    engineRpm < 1000f -> 950f + (engineRpm - 650f) * 1.2f
                    engineRpm in 1000f..1600f -> 1500f
                    else -> max(500f, 1500f - (engineRpm - 1600f) * 1.3f)
                }
                baseTorque * effectiveThrottle
            }
        }
    }

    fun calculateHorsepower(torqueNm: Float, rpm: Float): Float {
        val radS = rpm * (2f * Math.PI.toFloat() / 60f)
        val powerWatts = torqueNm * radS
        return (powerWatts / 745.7f).coerceAtLeast(0f)
    }

    fun updateTransmission(
        speedKmh: Float,
        throttleInput: Float,
        brakePedalInput: Float,
        dt: Float
    ) {
        if (!isEngineRunning) {
            engineRpm = 0f
            return
        }

        if (isShifting) {
            shiftTimerSec += dt
            if (shiftTimerSec > 0.35f) {
                isShifting = false
                shiftTimerSec = 0f
            }
            return
        }

        val ratios = if (transmissionType == TransmissionType.EATON_FULLER_18) gearRatios18 else gearRatios6
        val maxGears = ratios.size

        when (gearMode) {
            "D" -> {
                val ratio = if (currentGear in 1..maxGears) ratios[currentGear - 1] else 1.0f
                val wheelRpm = (speedKmh / 3.6f) / (0.505f) * (60f / (2 * Math.PI.toFloat()))
                val calcRpm = wheelRpm * finalDriveRatio * ratio

                engineRpm = calcRpm.coerceIn(powertrainType.idleRpm, powertrainType.maxRpm)

                val upshiftRpm = if (transmissionType == TransmissionType.EATON_FULLER_18) 1650f else 1850f
                val downshiftRpm = if (transmissionType == TransmissionType.EATON_FULLER_18) 1100f else 950f

                if (engineRpm > upshiftRpm && currentGear < maxGears) {
                    currentGear++
                    isShifting = true
                    shiftTimerSec = 0f
                } else if (engineRpm < downshiftRpm && currentGear > 1) {
                    currentGear--
                    isShifting = true
                    shiftTimerSec = 0f
                }
            }
            "R" -> {
                currentGear = -1
                val wheelRpm = (speedKmh / 3.6f) / (0.505f) * (60f / (2 * Math.PI.toFloat()))
                engineRpm = (wheelRpm * finalDriveRatio * reverseRatio).coerceIn(powertrainType.idleRpm, powertrainType.maxRpm)
            }
            "N", "P" -> {
                currentGear = 0
                val targetRpm = powertrainType.idleRpm + throttleInput * 1200f
                engineRpm += (targetRpm - engineRpm) * (dt * 5f)
            }
        }
    }

    fun getWheelTorque(engineTorqueNm: Float): Float {
        if (currentGear == 0 || isShifting) return 0f
        val ratios = if (transmissionType == TransmissionType.EATON_FULLER_18) gearRatios18 else gearRatios6
        val ratio = when {
            currentGear == -1 -> -reverseRatio
            currentGear in 1..ratios.size -> ratios[currentGear - 1]
            else -> 1.0f
        }
        val diffMulti = if (isInterAxleDiffLocked) 1.05f else 1.0f
        return engineTorqueNm * ratio * finalDriveRatio * diffMulti * clutchEngagement
    }

    fun toggleSplitter(): Boolean {
        isSplitterHigh = !isSplitterHigh
        return isSplitterHigh
    }

    fun toggleRange(): Boolean {
        isHighRange = !isHighRange
        return isHighRange
    }

    fun toggleDiffLock(): Boolean {
        isInterAxleDiffLocked = !isInterAxleDiffLocked
        return isInterAxleDiffLocked
    }
}
