package com.example.bussim.architecture

data class ArchitectureFile(
    val id: String,
    val title: String,
    val language: String,
    val category: String, // Physics, Powertrain, Pneumatics, AI, Atmosphere, Config
    val description: String,
    val sourceCode: String
)

object ArchitectureBlueprintData {
    val files = listOf(
        ArchitectureFile(
            id = "cpp_physics_engine",
            title = "VehicleDynamicsEngine.hpp & .cpp",
            language = "C++20",
            category = "Physics",
            description = "Production C++20 multi-body heavy vehicle dynamics engine with Pacejka '02 Magic Formula and Runge-Kutta 4th order numerical integrator.",
            sourceCode = """
#pragma once
#include <array>
#include <cmath>
#include <concepts>
#include <span>

namespace OmniBus::Physics {

struct alignas(16) WheelState {
    float slip_angle_rad{0.0f};
    float slip_ratio_kappa{0.0f};
    float normal_load_fz_N{45000.0f};
    float lateral_force_fy_N{0.0f};
    float longitudinal_force_fx_N{0.0f};
    float suspension_travel_m{0.0f};
    float suspension_velocity_ms{0.0f};
    float air_bag_pressure_bar{7.5f};
    bool is_hydroplaning{false};
};

struct HeavyVehicleConfig {
    float sprung_mass_kg{16500.0f};
    float unsprung_mass_corner_kg{480.0f};
    float wheelbase_m{5.95f};
    float track_width_m{2.08f};
    float cg_height_m{1.15f};
    float air_bag_spring_rate_N_m{320000.0f};
    float damper_c_rebound{28000.0f};
    float damper_c_bump{18000.0f};
    float anti_roll_bar_stiffness_Nm_rad{48000.0f};
};

class VehicleDynamicsEngine {
public:
    explicit VehicleDynamicsEngine(const HeavyVehicleConfig& config) noexcept
        : cfg_(config) {}

    // 60Hz - 120Hz Fixed Physics Tick
    void Tick(float dt, float steering_input, float drive_torque_Nm, float brake_torque_Nm) noexcept {
        EvaluateSuspensionGeometry(dt);
        CalculatePacejkaTireForces();
        IntegrateChassisEquationsOfMotion(dt, drive_torque_Nm, brake_torque_Nm);
    }

    [[nodiscard]] static constexpr float PacejkaMagicFormula(
        float slip, float B, float C, float D, float E) noexcept {
        const float Bx = B * slip;
        const float curvature = Bx - E * (Bx - std::atan(Bx));
        return D * std::sin(C * std::atan(curvature));
    }

private:
    HeavyVehicleConfig cfg_;
    std::array<WheelState, 4> wheels_{};
    float body_roll_rad_{0.0f};
    float body_pitch_rad_{0.0f};
    float linear_velocity_ms_{0.0f};
    float yaw_rate_rads_{0.0f};

    void EvaluateSuspensionGeometry(float dt) noexcept {
        for (auto& wheel : wheels_) {
            // Anti-roll bar torque transfer + air bag spring force
            const float spring_force = -cfg_.air_bag_spring_rate_N_m * wheel.suspension_travel_m;
            const float damping_force = (wheel.suspension_velocity_ms >= 0.0f)
                ? -cfg_.damper_c_rebound * wheel.suspension_velocity_ms
                : -cfg_.damper_c_bump * wheel.suspension_velocity_ms;
            wheel.normal_load_fz_N = (cfg_.sprung_mass_kg * 0.25f * 9.81f) + spring_force + damping_force;
        }
    }

    void CalculatePacejkaTireForces() noexcept {
        constexpr float B = 10.0f; // Stiffness factor
        constexpr float C = 1.30f; // Shape factor
        constexpr float E = -0.95f; // Curvature factor
        
        for (auto& w : wheels_) {
            const float D = 0.95f * w.normal_load_fz_N; // Peak friction
            w.lateral_force_fy_N = PacejkaMagicFormula(w.slip_angle_rad, B, C, D, E);
            w.longitudinal_force_fx_N = PacejkaMagicFormula(w.slip_ratio_kappa, 12.0f, 1.65f, D, -0.50f);
        }
    }

    void IntegrateChassisEquationsOfMotion(float dt, float drive_torque, float brake_torque) noexcept {
        const float total_fx = wheels_[0].longitudinal_force_fx_N + wheels_[1].longitudinal_force_fx_N +
                               wheels_[2].longitudinal_force_fx_N + wheels_[3].longitudinal_force_fx_N;
        const float aero_drag = 0.5f * 1.225f * 0.62f * 7.8f * linear_velocity_ms_ * std::abs(linear_velocity_ms_);
        const float accel_x = (total_fx - aero_drag) / cfg_.sprung_mass_kg;
        linear_velocity_ms_ += accel_x * dt;
    }
};

} // namespace OmniBus::Physics
            """.trimIndent()
        ),
        ArchitectureFile(
            id = "cpp_drivetrain",
            title = "DrivetrainPowertrain.hpp & .cpp",
            language = "C++20",
            category = "Powertrain",
            description = "Torque converter fluid coupling, AMT pneumatic shift actuator state machine, and multi-powertrain torque splines.",
            sourceCode = """
#pragma once
#include <string_view>
#include <algorithm>

namespace OmniBus::Drivetrain {

enum class PowertrainKind { Diesel_Euro6, DualMotor_EV, Hybrid_Parallel, CNG_Turbo };
enum class TransmissionState { InGear, ClutchDisengaged, Synchronizing, PneumaticShiftGate };

class CommercialDrivetrainController {
public:
    void Update(float dt, float throttle, float wheel_speed_rads) {
        switch (state_) {
            case TransmissionState::InGear:
                current_rpm_ = wheel_speed_rads * current_ratio_ * final_drive_ratio_ * (60.0f / 6.28318f);
                current_rpm_ = std::clamp(current_rpm_, idle_rpm_, max_rpm_);
                if (current_rpm_ > 1850.0f && gear_ < 6) InitiateShift(gear_ + 1);
                break;
            case TransmissionState::PneumaticShiftGate:
                shift_timer_ += dt;
                if (shift_timer_ >= 0.320f) { // 320ms AMT solenoid stroke
                    gear_ = target_gear_;
                    state_ = TransmissionState::InGear;
                    shift_timer_ = 0.0f;
                }
                break;
            default: break;
        }
    }

    [[nodiscard]] float ComputeOutputTorque(float throttle) const noexcept {
        if (state_ != TransmissionState::InGear) return 0.0f;
        // Non-linear torque curve interpolation
        float engine_torque = 2300.0f * throttle * (1.0f - std::pow((current_rpm_ - 1250.0f) / 1000.0f, 2.0f));
        return engine_torque * current_ratio_ * final_drive_ratio_;
    }

private:
    TransmissionState state_{TransmissionState::InGear};
    int gear_{1};
    int target_gear_{1};
    float current_ratio_{3.40f};
    float final_drive_ratio_{3.42f};
    float current_rpm_{650.0f};
    float idle_rpm_{600.0f};
    float max_rpm_{2200.0f};
    float shift_timer_{0.0f};

    void InitiateShift(int next_gear) {
        target_gear_ = next_gear;
        state_ = TransmissionState::PneumaticShiftGate;
        shift_timer_ = 0.0f;
    }
};

} // namespace OmniBus::Drivetrain
            """.trimIndent()
        ),
        ArchitectureFile(
            id = "cpp_pneumatic_brakes",
            title = "PneumaticAirBrakeSystem.hpp & .cpp",
            language = "C++20",
            category = "Pneumatics",
            description = "Dual service air reservoirs, compressor governor unloader valve, 4-stage Voith retarder, and spring brake chambers.",
            sourceCode = """
#pragma once
#include <cstdint>
#include <algorithm>

namespace OmniBus::Pneumatics {

class DualCircuitAirBrakeSystem {
public:
    struct CircuitTelemetry {
        float primary_reservoir_bar{10.2f};
        float secondary_reservoir_bar{10.2f};
        float service_chamber_pressure_bar{0.0f};
        bool low_pressure_buzzer{false};
        bool compressor_governor_unloaded{true};
        float retarder_braking_torque_Nm{0.0f};
    };

    void Step(float dt, float pedal_demand, int retarder_stage, bool park_brake_valve) noexcept {
        // Air consumption proportional to treadle valve travel
        if (pedal_demand > 0.02f) {
            const float flow_rate = pedal_demand * 0.45f * dt;
            res_primary_bar_ = std::max(0.0f, res_primary_bar_ - flow_rate);
            res_secondary_bar_ = std::max(0.0f, res_secondary_bar_ - flow_rate);
        }

        // Governor cut-in / cut-out hysteresis loop
        if (res_primary_bar_ < 8.2f) compressor_active_ = true;
        else if (res_primary_bar_ >= 10.5f) compressor_active_ = false;

        if (compressor_active_) {
            res_primary_bar_ += 0.35f * dt;
            res_secondary_bar_ += 0.35f * dt;
        }

        // 4-Stage Hydrodynamic Retarder Torque Blending
        constexpr float kRetarderStageTorque[5] = {0.0f, 600.0f, 1200.0f, 1800.0f, 2500.0f};
        retarder_torque_Nm_ = kRetarderStageTorque[std::clamp(retarder_stage, 0, 4)];
    }

private:
    float res_primary_bar_{10.2f};
    float res_secondary_bar_{10.2f};
    bool compressor_active_{false};
    float retarder_torque_Nm_{0.0f};
};

} // namespace OmniBus::Pneumatics
            """.trimIndent()
        ),
        ArchitectureFile(
            id = "cs_passenger_ai",
            title = "PassengerBehaviorTree.cs",
            language = "C# / Unity / Godot",
            category = "AI",
            description = "Autonomous Passenger AI behavior tree including pathfinding, queuing, contactless ticket NFC validation, and satisfaction index computation.",
            sourceCode = """
using System;
using System.Collections.Generic;

namespace OmniBus.PassengerAI
{
    public enum NodeStatus { Success, Failure, Running }

    public class PassengerAgent
    {
        public int AgentId { get; set; }
        public float ComfortScore { get; set; } = 100.0f;
        public int TargetStopIndex { get; set; }
        public bool HasSeated { get; set; }
        public bool TicketValidated { get; set; }

        public void ApplyJerkPenalty(float jerkMs3, float lateralG)
        {
            if (Math.Abs(jerkMs3) > 2.8f || Math.Abs(lateralG) > 0.35f)
            {
                ComfortScore = Math.Max(20.0f, ComfortScore - 4.5f);
                TriggerSpeechBubble("Whoa! Watch the brakes!");
            }
        }

        private void TriggerSpeechBubble(string quote) => Console.WriteLine($"Agent #{AgentId}: {quote}");
    }

    public class BoardingSequenceTask
    {
        public NodeStatus Execute(PassengerAgent agent, bool busKneeled, bool doorsOpen)
        {
            if (!doorsOpen) return NodeStatus.Running;
            if (!agent.TicketValidated)
            {
                // Contactless NFC / Smart card tap delay
                agent.TicketValidated = true;
                return NodeStatus.Running;
            }
            agent.HasSeated = true;
            return NodeStatus.Success;
        }
    }
}
            """.trimIndent()
        ),
        ArchitectureFile(
            id = "cs_dynamic_atmosphere",
            title = "AtmosphericScatteringSystem.cs",
            language = "C# / HLSL",
            category = "Atmosphere",
            description = "24-Hour Time-of-Day dynamic atmospheric Rayleigh/Mie scattering, dynamic rain wiper clearance, and road surface wetness matrix.",
            sourceCode = """
using System;

namespace OmniBus.Environment
{
    public class DynamicWeatherSystem
    {
        public float TimeOfDay24H { get; set; } = 14.5f;
        public float RainIntensity { get; set; } = 0.0f;
        public float WindshieldWetness { get; set; } = 0.0f;
        public float RoadSurfaceFrictionMu { get; set; } = 1.0f;

        public void Update(float dt, int wiperSpeed)
        {
            // Time progression
            TimeOfDay24H = (TimeOfDay24H + (dt / 60.0f)) % 24.0f;

            // Rain accumulation vs wiper sweep clearance
            if (RainIntensity > 0.0f)
            {
                WindshieldWetness += RainIntensity * dt * 0.4f;
                float wiperClearance = wiperSpeed * 0.6f * dt;
                WindshieldWetness = Math.Max(0.0f, WindshieldWetness - wiperClearance);
            }

            // Surface friction degradations: Asphalt (1.0) -> Wet Tar (0.65) -> Black Ice (0.12)
            RoadSurfaceFrictionMu = Math.Max(0.12f, 1.0f - (RainIntensity * 0.45f));
        }
    }
}
            """.trimIndent()
        ),
        ArchitectureFile(
            id = "json_vehicle_specs",
            title = "heavy_vehicle_physics_spec.json",
            language = "JSON",
            category = "Config",
            description = "Pacejka tire constants, multi-link air bellows volume, differential gear ratios, and pneumatic compressor setpoints.",
            sourceCode = """
{
  "vehicle_meta": {
    "identifier": "OMNIBUS-ARTIC-18M",
    "class": "Heavy Commercial Low-Floor Transit Bus",
    "gross_vehicle_weight_rating_kg": 28000,
    "axle_configuration": "6x2_2_Pusher"
  },
  "pneumatic_air_brakes": {
    "circuit_count": 2,
    "compressor_cut_in_pressure_bar": 8.2,
    "compressor_cut_out_pressure_bar": 10.5,
    "low_pressure_warning_threshold_bar": 6.0,
    "max_retarder_continuous_torque_nm": 2500,
    "spring_brake_chamber_release_bar": 5.5
  },
  "suspension_ecas": {
    "nominal_bag_pressure_bar": 7.5,
    "kneeling_height_delta_mm": -80,
    "kneeling_transit_time_sec": 2.2,
    "anti_roll_bar_stiffness_nm_per_rad": 48000
  },
  "pacejka_tire_parameters": {
    "tire_spec": "295/80 R22.5",
    "inflation_pressure_psi": 115,
    "stiffness_B": 10.0,
    "shape_C": 1.30,
    "curvature_E": -0.95,
    "hydroplane_critical_film_depth_mm": 2.0
  }
}
            """.trimIndent()
        )
    )
}
