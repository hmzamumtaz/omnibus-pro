package com.example.bussim.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.CarRental
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bussim.physics.VehicleTelemetry
import com.example.bussim.viewmodel.BusSimulatorViewModel
import com.example.bussim.viewmodel.CameraView
import com.example.bussim.viewmodel.SimulatorUiState

@Composable
fun CockpitControls(
    viewModel: BusSimulatorViewModel,
    state: SimulatorUiState,
    modifier: Modifier = Modifier
) {
    val telemetry = state.telemetry

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 2.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Camera View Mode Selector Pills
        CameraSelectorRow(
            currentCamera = state.cameraView,
            onSelectCamera = { viewModel.setCameraView(it) }
        )

        // Digital Dashboard Gauges Cluster
        DashboardInstrumentCluster(telemetry = telemetry)

        // Commercial Bus Cockpit Switches (Pneumatics, Doors, Kneeling, Retarder)
        InteractiveSwitchboard(
            telemetry = telemetry,
            viewModel = viewModel
        )

        // Steering & Pedals Control Deck
        DriverPedalsAndSteering(
            viewModel = viewModel,
            steeringInput = state.steeringInput,
            throttleInput = state.throttleInput,
            brakeInput = state.brakeInput
        )
    }
}

@Composable
fun CameraSelectorRow(
    currentCamera: CameraView,
    onSelectCamera: (CameraView) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("camera_selector_row"),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        CameraView.values().forEach { cam ->
            val isSelected = currentCamera == cam
            val label = when (cam) {
                CameraView.COCKPIT -> "Cockpit"
                CameraView.CHASE_3D -> "Chase 3D"
                CameraView.PASSENGER_CCTV -> "Cabin CCTV"
                CameraView.SUSPENSION_CHASSIS -> "Chassis X-Ray"
            }
            Surface(
                onClick = { onSelectCamera(cam) },
                shape = RoundedCornerShape(8.dp),
                color = if (isSelected) Color(0xFF00E5FF) else Color(0xFF16202E),
                border = BorderStroke(1.dp, if (isSelected) Color(0xFF00E5FF) else Color(0xFF2C3C54)),
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp)
                    .testTag("camera_btn_${cam.name.lowercase()}")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = label,
                        color = if (isSelected) Color.Black else Color.White,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

@Composable
fun DashboardInstrumentCluster(telemetry: VehicleTelemetry) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF101722)),
        border = BorderStroke(1.dp, Color(0xFF233247)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dashboard_cluster")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 1. Speedometer
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f)
            ) {
                Text(text = "SPEED", fontSize = 10.sp, color = Color(0xFF90A4AE), fontWeight = FontWeight.Bold)
                Text(
                    text = "${telemetry.speedKmh.toInt()}",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF00E5FF)
                )
                Text(text = "km/h", fontSize = 10.sp, color = Color(0xFF90A4AE))
            }

            // 2. Tachometer & Turbo Boost
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1.2f)
            ) {
                Text(text = "RPM × 100", fontSize = 10.sp, color = Color(0xFF90A4AE), fontWeight = FontWeight.Bold)
                Text(
                    text = "${(telemetry.engineRpm / 100f).toInt()}",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    color = if (telemetry.engineRpm > 1900f) Color(0xFFFF3D00) else Color(0xFF00E676)
                )
                Text(
                    text = "Boost: ${"%.1f".format(telemetry.turboBoostBar)} bar",
                    fontSize = 10.sp,
                    color = Color(0xFFFFB300),
                    fontFamily = FontFamily.Monospace
                )
            }

            // 3. Dual Air Brake Pressure Tanks
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1.2f)
            ) {
                Text(text = "AIR TANKS", fontSize = 10.sp, color = Color(0xFF90A4AE), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    val tank1Color = if (telemetry.tank1PressureBar < 6.0f) Color.Red else Color(0xFF00E5FF)
                    val tank2Color = if (telemetry.tank2PressureBar < 6.0f) Color.Red else Color(0xFF00E5FF)
                    Text(
                        text = "F:${"%.1f".format(telemetry.tank1PressureBar)}",
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        color = tank1Color,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "R:${"%.1f".format(telemetry.tank2PressureBar)}",
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        color = tank2Color,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = if (telemetry.tank1PressureBar < 6.0f) "LOW AIR!" else "Dual Circuit",
                    fontSize = 10.sp,
                    color = if (telemetry.tank1PressureBar < 6.0f) Color.Red else Color(0xFF90A4AE)
                )
            }

            // 4. Retarder & Comfort Index
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1.1f)
            ) {
                Text(text = "RETARDER", fontSize = 10.sp, color = Color(0xFF90A4AE), fontWeight = FontWeight.Bold)
                Text(
                    text = if (telemetry.retarderLevel > 0) "STAGE ${telemetry.retarderLevel}" else "OFF",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (telemetry.retarderLevel > 0) Color(0xFFFF9100) else Color(0xFF90A4AE)
                )
                Text(
                    text = "Comfort: ${telemetry.passengerComfortScore.toInt()}%",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (telemetry.passengerComfortScore > 80f) Color(0xFF00E676) else Color(0xFFFF3D00)
                )
            }
        }
    }
}

@Composable
fun InteractiveSwitchboard(
    telemetry: VehicleTelemetry,
    viewModel: BusSimulatorViewModel
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141C28)),
        border = BorderStroke(1.dp, Color(0xFF253448)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("interactive_switchboard")
    ) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Gear Selector Buttons (P, R, N, D)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("P", "R", "N", "D").forEach { mode ->
                    val isSelected = telemetry.gearMode == mode
                    Surface(
                        onClick = { viewModel.setGearMode(mode) },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) Color(0xFFFFB300) else Color(0xFF1E2B3E),
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("gear_btn_$mode")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = mode,
                                color = if (isSelected) Color.Black else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }

            // Pneumatic & Auxiliary Function Toggle Switches
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Park Brake (Maxi Valve)
                CockpitSwitchButton(
                    label = "PARK",
                    subtext = if (telemetry.parkingBrake) "APPLIED" else "RELEASED",
                    isActive = telemetry.parkingBrake,
                    activeColor = Color(0xFFFF3D00),
                    onClick = { viewModel.toggleParkingBrake() },
                    modifier = Modifier.weight(1f),
                    testTag = "switch_park_brake"
                )

                // Retarder Wand Cycle
                CockpitSwitchButton(
                    label = "RETARD",
                    subtext = "STG ${telemetry.retarderLevel}",
                    isActive = telemetry.retarderLevel > 0,
                    activeColor = Color(0xFFFF9100),
                    onClick = { viewModel.cycleRetarder() },
                    modifier = Modifier.weight(1f),
                    testTag = "switch_retarder"
                )

                // Kneeling Suspension
                CockpitSwitchButton(
                    label = "KNEEL",
                    subtext = if (telemetry.isKneeling) "-80mm" else "NORMAL",
                    isActive = telemetry.isKneeling,
                    activeColor = Color(0xFF00E5FF),
                    onClick = { viewModel.toggleKneeling() },
                    modifier = Modifier.weight(1f),
                    testTag = "switch_kneeling"
                )

                // Door 1 (Front)
                CockpitSwitchButton(
                    label = "DOOR 1",
                    subtext = if (telemetry.door1Open) "OPEN" else "SHUT",
                    isActive = telemetry.door1Open,
                    activeColor = Color(0xFF00E676),
                    onClick = { viewModel.toggleDoor1() },
                    modifier = Modifier.weight(1f),
                    testTag = "switch_door_1"
                )

                // Door 2 (Rear) or Trailer Supply Valve
                if (telemetry.vehicleCategory == com.example.bussim.physics.VehicleCategory.HEAVY_TRUCK_SEMI) {
                    CockpitSwitchButton(
                        label = "TRLR AIR",
                        subtext = if (telemetry.trailerSupplyValvePopped) "POPPED" else "CHARGED",
                        isActive = telemetry.trailerSupplyValvePopped,
                        activeColor = Color(0xFFD50000),
                        onClick = { viewModel.toggleTrailerSupplyValve() },
                        modifier = Modifier.weight(1f),
                        testTag = "switch_trailer_air"
                    )
                } else {
                    CockpitSwitchButton(
                        label = "DOOR 2",
                        subtext = if (telemetry.door2Open) "OPEN" else "SHUT",
                        isActive = telemetry.door2Open,
                        activeColor = Color(0xFF00E676),
                        onClick = { viewModel.toggleDoor2() },
                        modifier = Modifier.weight(1f),
                        testTag = "switch_door_2"
                    )
                }
            }

            // Heavy Truck Specific Controls: Eaton Fuller Range, Splitter, 3-Stage Jake, Diff Lock
            if (telemetry.vehicleCategory == com.example.bussim.physics.VehicleCategory.HEAVY_TRUCK_SEMI) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CockpitSwitchButton(
                        label = "RANGE",
                        subtext = if (viewModel.physicsEngine.drivetrain.isHighRange) "HIGH (5-8)" else "LOW (1-4)",
                        isActive = viewModel.physicsEngine.drivetrain.isHighRange,
                        activeColor = Color(0xFF00E5FF),
                        onClick = { viewModel.toggleRange() },
                        modifier = Modifier.weight(1f),
                        testTag = "switch_range"
                    )

                    CockpitSwitchButton(
                        label = "SPLITTER",
                        subtext = if (viewModel.physicsEngine.drivetrain.isSplitterHigh) "OVERDRIVE" else "DIRECT",
                        isActive = viewModel.physicsEngine.drivetrain.isSplitterHigh,
                        activeColor = Color(0xFFFFB300),
                        onClick = { viewModel.toggleSplitter() },
                        modifier = Modifier.weight(1f),
                        testTag = "switch_splitter"
                    )

                    CockpitSwitchButton(
                        label = "JAKE 3-STG",
                        subtext = if (telemetry.jakeBrakeStage > 0) "STAGE ${telemetry.jakeBrakeStage}" else "OFF",
                        isActive = telemetry.jakeBrakeStage > 0,
                        activeColor = Color(0xFFB388FF),
                        onClick = { viewModel.cycleJakeBrake() },
                        modifier = Modifier.weight(1f),
                        testTag = "switch_jake_stage"
                    )

                    CockpitSwitchButton(
                        label = "DIFF LOCK",
                        subtext = if (telemetry.isDiffLocked) "LOCKED" else "OPEN",
                        isActive = telemetry.isDiffLocked,
                        activeColor = Color(0xFF00E676),
                        onClick = { viewModel.toggleDiffLock() },
                        modifier = Modifier.weight(1f),
                        testTag = "switch_diff_lock"
                    )
                }
            }

            // Auxiliary Secondary Controls (Air Horn, Climate A/C, Wipers, Hazard)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Air Horn Button
                Surface(
                    onClick = { viewModel.blastHorn() },
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF37474F),
                    modifier = Modifier.weight(1.1f).height(38.dp).testTag("btn_air_horn")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(text = "📢 AIR HORN", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFD54F))
                    }
                }

                // Climate A/C Toggle
                Surface(
                    onClick = { viewModel.toggleAc() },
                    shape = RoundedCornerShape(8.dp),
                    color = if (telemetry.acActive) Color(0xFF132F38) else Color(0xFF1E2B3E),
                    border = BorderStroke(1.dp, if (telemetry.acActive) Color(0xFF00E5FF) else Color.Transparent),
                    modifier = Modifier.weight(1.1f).height(38.dp).testTag("btn_climate_ac")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "A/C ${"%.1f".format(telemetry.cabinTempC)}°C",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (telemetry.acActive) Color(0xFF00E5FF) else Color(0xFF90A4AE)
                        )
                    }
                }

                // Wipers
                Surface(
                    onClick = { viewModel.cycleWipers() },
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF1E2B3E),
                    modifier = Modifier.weight(1f).height(38.dp).testTag("btn_wiper")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.WaterDrop, contentDescription = "Wipers", tint = Color(0xFF00E5FF), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(text = "Wiper", fontSize = 11.sp, color = Color.White)
                    }
                }

                // Hazard
                Surface(
                    onClick = { viewModel.toggleHazardLights() },
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF1E2B3E),
                    modifier = Modifier.weight(1f).height(38.dp).testTag("btn_hazard")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Hazard", tint = Color(0xFFFF9100), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(text = "Hazard", fontSize = 11.sp, color = Color.White)
                    }
                }
            }

            // Rotor Temperature & Thermal Fade Warning Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Brake Rotor: ${telemetry.brakeRotorTempC.toInt()}°C",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (telemetry.brakeRotorTempC > 450f) Color(0xFFFF3D00) else Color(0xFF90A4AE)
                )
                Text(
                    text = if (telemetry.brakeFadePercent > 5f) "THERMAL FADE -${telemetry.brakeFadePercent.toInt()}%" else "Pad Friction: 100%",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (telemetry.brakeFadePercent > 5f) Color(0xFFFF3D00) else Color(0xFF00E676)
                )
            }
        }
    }
}

@Composable
fun CockpitSwitchButton(
    label: String,
    subtext: String,
    isActive: Boolean,
    activeColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = if (isActive) activeColor.copy(alpha = 0.25f) else Color(0xFF1C2738),
        border = BorderStroke(1.dp, if (isActive) activeColor else Color(0xFF2C3C54)),
        modifier = modifier
            .height(52.dp)
            .testTag(testTag)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(2.dp)
        ) {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isActive) activeColor else Color.White
            )
            Text(
                text = subtext,
                fontSize = 9.sp,
                color = if (isActive) activeColor else Color(0xFF90A4AE)
            )
        }
    }
}

@Composable
fun DriverPedalsAndSteering(
    viewModel: BusSimulatorViewModel,
    steeringInput: Float,
    throttleInput: Float,
    brakeInput: Float
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF101722)),
        border = BorderStroke(1.dp, Color(0xFF233247)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("driver_pedals_deck")
    ) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Steering Wheel Slider with Center Indicator
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "STEERING",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF90A4AE)
                )
                Text(
                    text = "${(steeringInput * 100).toInt()}%",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF00E5FF)
                )
            }

            Slider(
                value = steeringInput,
                onValueChange = { viewModel.setSteering(it) },
                valueRange = -1f..1f,
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFF00E5FF),
                    activeTrackColor = Color(0xFF00E5FF),
                    inactiveTrackColor = Color(0xFF2C3C54)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("steering_slider")
            )

            // Brake & Throttle Foot Pedals Deck
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Progressive Air Brake Pedal
                PressurePedal(
                    label = "BRAKE (Air)",
                    sublabel = "Dual Circuit",
                    currentValue = brakeInput,
                    accentColor = Color(0xFFFF3D00),
                    onValueChange = { viewModel.setBrake(it) },
                    modifier = Modifier.weight(1f),
                    testTag = "brake_pedal"
                )

                // Progressive Throttle Pedal
                PressurePedal(
                    label = "THROTTLE",
                    sublabel = "Drive Axle",
                    currentValue = throttleInput,
                    accentColor = Color(0xFF00E676),
                    onValueChange = { viewModel.setThrottle(it) },
                    modifier = Modifier.weight(1f),
                    testTag = "throttle_pedal"
                )
            }
        }
    }
}

@Composable
fun PressurePedal(
    label: String,
    sublabel: String,
    currentValue: Float,
    accentColor: Color,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    testTag: String
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFF16202E),
        border = BorderStroke(1.dp, if (currentValue > 0.05f) accentColor else Color(0xFF2C3C54)),
        modifier = modifier
            .height(72.dp)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        try {
                            onValueChange(1.0f)
                            awaitRelease()
                        } finally {
                            onValueChange(0f)
                        }
                    }
                )
            }
            .testTag(testTag)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(6.dp)
        ) {
            Text(
                text = label,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (currentValue > 0.05f) accentColor else Color.White
            )
            Text(
                text = sublabel,
                fontSize = 10.sp,
                color = Color(0xFF90A4AE)
            )
            Spacer(modifier = Modifier.height(4.dp))
            // Pressure bar
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF233247))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(currentValue)
                        .height(6.dp)
                        .background(accentColor)
                )
            }
        }
    }
}
