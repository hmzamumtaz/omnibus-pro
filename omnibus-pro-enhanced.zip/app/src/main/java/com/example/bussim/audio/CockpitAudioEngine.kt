package com.example.bussim.audio

import android.media.AudioManager
import android.media.ToneGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Synthetic audio engine for commercial vehicle cockpit acoustics:
 * - Pneumatic air purge pop-off release
 * - Low-air warning alarm buzzer
 * - Stop request chime (two-tone chime)
 * - Turn signal blinker relay click
 * - Air horn blast
 * - Retarder whine
 */
object CockpitAudioEngine {
    private var toneGen: ToneGenerator? = null

    init {
        try {
            toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 85)
        } catch (e: Exception) {
            toneGen = null
        }
    }

    fun playAirPurge(scope: CoroutineScope) {
        scope.launch(Dispatchers.Default) {
            try {
                // High frequency burst followed by low hiss simulation
                toneGen?.startTone(ToneGenerator.TONE_PROP_BEEP2, 120)
            } catch (e: Exception) {}
        }
    }

    fun playLowAirAlarm(scope: CoroutineScope) {
        scope.launch(Dispatchers.Default) {
            try {
                toneGen?.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 300)
            } catch (e: Exception) {}
        }
    }

    fun playStopChime(scope: CoroutineScope) {
        scope.launch(Dispatchers.Default) {
            try {
                toneGen?.startTone(ToneGenerator.TONE_DTMF_D, 180)
                delay(120)
                toneGen?.startTone(ToneGenerator.TONE_DTMF_A, 250)
            } catch (e: Exception) {}
        }
    }

    fun playTurnSignalTick(scope: CoroutineScope) {
        scope.launch(Dispatchers.Default) {
            try {
                toneGen?.startTone(ToneGenerator.TONE_PROP_PROMPT, 45)
            } catch (e: Exception) {}
        }
    }

    fun playAirHorn(scope: CoroutineScope) {
        scope.launch(Dispatchers.Default) {
            try {
                toneGen?.startTone(ToneGenerator.TONE_DTMF_0, 650)
            } catch (e: Exception) {}
        }
    }

    fun playRetarderWhine(scope: CoroutineScope) {
        scope.launch(Dispatchers.Default) {
            try {
                toneGen?.startTone(ToneGenerator.TONE_DTMF_1, 150)
            } catch (e: Exception) {}
        }
    }

    fun playJakeBrakeRattle(scope: CoroutineScope) {
        scope.launch(Dispatchers.Default) {
            try {
                toneGen?.startTone(ToneGenerator.TONE_PROP_BEEP, 80)
                delay(60)
                toneGen?.startTone(ToneGenerator.TONE_PROP_BEEP, 80)
            } catch (e: Exception) {}
        }
    }
}
