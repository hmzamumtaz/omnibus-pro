package com.example.bussim.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bussim.passenger.PassengerAgent
import com.example.bussim.passenger.PassengerState
import com.example.bussim.viewmodel.BusSimulatorViewModel
import com.example.bussim.viewmodel.SimulatorUiState
import com.example.bussim.world.WeatherCondition
import kotlin.math.abs

@Composable
fun RoutesAndPassengerScreen(
    viewModel: BusSimulatorViewModel,
    state: SimulatorUiState,
    modifier: Modifier = Modifier
) {
    val route = state.currentRoute
    val nextStop = state.nextStop

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp)
            .testTag("routes_passenger_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Next Stop & Boarding Live Banner
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (state.isAtStop) Color(0xFF0D2818) else Color(0xFF141E2C)
                ),
                border = BorderStroke(1.dp, if (state.isAtStop) Color(0xFF00E676) else Color(0xFF2C3E55)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("stop_status_banner")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = if (state.isAtStop) Color(0xFF00E676) else Color(0xFF00E5FF),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (state.isAtStop) "AT BUS STOP (READY TO BOARD)" else "NEXT TRANSIT STOP",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (state.isAtStop) Color(0xFF00E676) else Color(0xFF00E5FF)
                            )
                        }
                        if (state.stopRequestedChime) {
                            Surface(
                                color = Color(0xFFFF1744),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "STOP REQUESTED",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Text(
                        text = nextStop?.name ?: "Route Completed - End of Line",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Distance: ${"%.0f".format(state.distanceToNextStopM)}m",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFFFB300)
                        )
                        Text(
                            text = "Waiting: ${nextStop?.waitingPassengers ?: 0} | Alighting: ${nextStop?.alightingPassengers ?: 0}",
                            fontSize = 12.sp,
                            color = Color(0xFF90A4AE)
                        )
                    }

                    if (state.isAtStop) {
                        Text(
                            text = "💡 Tip: Lower bus with [KNEEL] and open [DOOR 1] or [DOOR 2] to board passengers.",
                            fontSize = 11.sp,
                            color = Color(0xFFB9F6CA)
                        )
                    }
                }
            }
        }

        // 2. Weather & Environment Scenario Selector
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101722)),
                border = BorderStroke(1.dp, Color(0xFF233247)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ENVIRONMENT & SURFACE SIMULATION",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF90A4AE)
                        )
                        Text(
                            text = "Road Grip μ: ${state.weather.surfaceType.frictionCoefficient}",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF00E5FF)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        WeatherCondition.values().take(4).forEach { w ->
                            val isSel = state.weather == w
                            Surface(
                                onClick = { viewModel.setWeather(w) },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) Color(0xFF00E5FF) else Color(0xFF1C2738),
                                modifier = Modifier.weight(1f).height(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = w.displayName.take(8),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) Color.Black else Color.White
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        WeatherCondition.values().drop(4).forEach { w ->
                            val isSel = state.weather == w
                            Surface(
                                onClick = { viewModel.setWeather(w) },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) Color(0xFFFFB300) else Color(0xFF1C2738),
                                modifier = Modifier.weight(1f).height(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = w.displayName.take(12),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) Color.Black else Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Route Selector
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101722)),
                border = BorderStroke(1.dp, Color(0xFF233247)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "SELECT ACTIVE TRANSIT ROUTE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF90A4AE)
                    )

                    viewModel.routeManager.routes.forEachIndexed { index, r ->
                        val isSelected = r.routeId == route?.routeId
                        Surface(
                            onClick = { viewModel.selectRoute(index) },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) Color(0xFF1A334B) else Color(0xFF16202E),
                            border = BorderStroke(1.dp, if (isSelected) Color(0xFF00E5FF) else Color(0xFF253448)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "[${r.routeNumber}] ${r.title}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color(0xFF00E5FF) else Color.White
                                    )
                                    Text(
                                        text = "${r.biome} • ${r.stops.size} Stops • ${(r.totalDistanceMeters / 1000f)} km",
                                        fontSize = 11.sp,
                                        color = Color(0xFF90A4AE)
                                    )
                                }
                                Text(
                                    text = "$${"%.2f".format(r.baseFarePerPassenger)}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF00E676)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4. Passenger Satisfaction & Jerk Telemetry
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101722)),
                border = BorderStroke(1.dp, Color(0xFF233247)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PASSENGER COMFORT INDEX",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF90A4AE)
                        )
                        Text(
                            text = "${"%.1f".format(state.averageSatisfaction)}%",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (state.averageSatisfaction > 80f) Color(0xFF00E676) else Color(0xFFFF3D00)
                        )
                        Text(
                            text = "Jerk: ${"%.2f".format(state.telemetry.jerkMs3)} m/s³ | Lat G: ${"%.2f".format(state.telemetry.lateralG)}G",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFFFB300)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "ONBOARD: ${state.activePassengers.size}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00E5FF)
                        )
                        Text(
                            text = "Revenue: $${"%.2f".format(viewModel.passengerManager.cumulativeRevenue)}",
                            fontSize = 12.sp,
                            color = Color(0xFF00E676),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 5. Active Passengers Live Roster
        item {
            Text(
                text = "PASSENGERS ON BOARD (${state.activePassengers.size})",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF90A4AE),
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        items(state.activePassengers) { passenger ->
            PassengerItemCard(passenger = passenger)
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun PassengerItemCard(passenger: PassengerAgent) {
    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141C28)),
        border = BorderStroke(1.dp, Color(0xFF253448)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    passenger.satisfactionPercent > 85f -> Color(0xFF00E676)
                                    passenger.satisfactionPercent > 60f -> Color(0xFFFFB300)
                                    else -> Color(0xFFFF3D00)
                                }
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${passenger.name} (${passenger.type.label})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Text(
                    text = "${passenger.satisfactionPercent.toInt()}%",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (passenger.satisfactionPercent > 80f) Color(0xFF00E676) else Color(0xFFFF9100)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Fare: ${passenger.type.ticketType} • Seat #${passenger.seatNumber}",
                    fontSize = 11.sp,
                    color = Color(0xFF90A4AE)
                )
                Text(
                    text = "State: ${passenger.state.name}",
                    fontSize = 10.sp,
                    color = Color(0xFF00E5FF)
                )
            }

            // Live Speech Bubble if speaking
            passenger.currentSpeechBubble?.let { quote ->
                Surface(
                    color = Color(0xFF1F2B3E),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.padding(top = 2.dp)
                ) {
                    Text(
                        text = "💬 \"$quote\"",
                        fontSize = 11.sp,
                        color = Color(0xFFFFE082),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}
