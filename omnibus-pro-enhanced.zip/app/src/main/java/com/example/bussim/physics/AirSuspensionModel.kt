package com.example.bussim.physics

import kotlin.math.abs

/**
 * Multi-Link Air Suspension Simulation with ECAS (Electronically Controlled Air Suspension)
 */
class AirSuspensionModel(
    var stiffnessMultiplier: Float = 1.0f,
    var nominalHeightMm: Float = 0f
) {
    data class WheelSuspension(
        var displacementMm: Float = 0f,
        var velocityMmS: Float = 0f,
        var bagPressureBar: Float = 7.5f,
        var loadN: Float = 45000f,
        var temperatureC: Float = 30f
    )

    val frontLeft = WheelSuspension()
    val frontRight = WheelSuspension()
    val rearLeft = WheelSuspension()
    val rearRight = WheelSuspension()

    var isKneeling: Boolean = false
    var currentKneelOffsetMm: Float = 0f // 0 to -80mm
    var antiRollBarStiffnessNmPerRad: Float = 45000f
    var bodyRollAngleDeg: Float = 0f
    var bodyPitchAngleDeg: Float = 0f

    // Spring constants for heavy commercial bus bellows
    private val baseSpringRateNPerM = 320000f // ~320 N/mm per corner
    private val reboundDampingRate = 28000f
    private val compressionDampingRate = 18000f

    fun update(
        dt: Float,
        speedMs: Float,
        accelLongMs2: Float,
        accelLatMs2: Float,
        chassisMassKg: Float,
        isBraking: Boolean
    ) {
        // ECAS Kneeling transition
        val targetKneel = if (isKneeling) -80f else 0f
        if (abs(currentKneelOffsetMm - targetKneel) > 0.5f) {
            val step = 40f * dt // 2 seconds to fully kneel
            if (currentKneelOffsetMm > targetKneel) {
                currentKneelOffsetMm = (currentKneelOffsetMm - step).coerceAtLeast(targetKneel)
            } else {
                currentKneelOffsetMm = (currentKneelOffsetMm + step).coerceAtMost(targetKneel)
            }
        }

        // Dynamic body roll from lateral acceleration (centrifugal force)
        val targetRollDeg = (accelLatMs2 / 9.81f) * 4.5f
        bodyRollAngleDeg += (targetRollDeg - bodyRollAngleDeg) * (dt * 6f)

        // Dynamic pitch from longitudinal acceleration/braking
        val targetPitchDeg = -(accelLongMs2 / 9.81f) * 3.8f
        bodyPitchAngleDeg += (targetPitchDeg - bodyPitchAngleDeg) * (dt * 7f)

        // Update wheel displacements based on roll, pitch, and kneeling
        val rollDisplacement = (bodyRollAngleDeg / 4.5f) * 35f
        val pitchDisplacement = (bodyPitchAngleDeg / 3.8f) * 45f

        frontLeft.displacementMm = -rollDisplacement + pitchDisplacement
        frontRight.displacementMm = rollDisplacement + pitchDisplacement + currentKneelOffsetMm
        rearLeft.displacementMm = -rollDisplacement - pitchDisplacement * 0.7f
        rearRight.displacementMm = rollDisplacement - pitchDisplacement * 0.7f + currentKneelOffsetMm * 0.8f

        // Air bellows pressure response
        frontLeft.bagPressureBar = 7.5f + (frontLeft.displacementMm / 100f) * 1.8f
        frontRight.bagPressureBar = 7.5f + (frontRight.displacementMm / 100f) * 1.8f
        rearLeft.bagPressureBar = 7.8f + (rearLeft.displacementMm / 100f) * 2.0f
        rearRight.bagPressureBar = 7.8f + (rearRight.displacementMm / 100f) * 2.0f
    }

    fun toggleKneel(): Boolean {
        isKneeling = !isKneeling
        return isKneeling
    }
}
