package com.example.bussim.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bussim.data.BusFleetEntity
import com.example.bussim.viewmodel.BusSimulatorViewModel
import com.example.bussim.viewmodel.SimulatorUiState

@Composable
fun GarageCustomizationScreen(
    viewModel: BusSimulatorViewModel,
    state: SimulatorUiState,
    modifier: Modifier = Modifier
) {
    val selectedBus = state.selectedBus ?: return

    var powertrain by remember(selectedBus.id) { mutableStateOf(selectedBus.powertrain) }
    var paintColor by remember(selectedBus.id) { mutableStateOf(selectedBus.paintColorHex) }
    var matrixLine by remember(selectedBus.id) { mutableStateOf(selectedBus.matrixLineNumber) }
    var matrixDest by remember(selectedBus.id) { mutableStateOf(selectedBus.matrixDestination) }
    var stiffness by remember(selectedBus.id) { mutableFloatStateOf(selectedBus.suspensionStiffness) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp)
            .testTag("garage_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Bus Fleet Selector Carousel
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "COMMERCIAL FLEET INVENTORY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF90A4AE)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(state.allBuses) { bus ->
                        val isSelected = bus.id == selectedBus.id
                        Surface(
                            onClick = { viewModel.selectBus(bus.id) },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) Color(0xFF1E3247) else Color(0xFF131B26),
                            border = BorderStroke(1.dp, if (isSelected) Color(0xFF00E5FF) else Color(0xFF253448)),
                            modifier = Modifier
                                .width(220.dp)
                                .height(100.dp)
                                .testTag("fleet_card_${bus.id}")
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = bus.id,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF00E5FF)
                                    )
                                    Text(
                                        text = bus.powertrain,
                                        fontSize = 10.sp,
                                        color = Color(0xFFFFB300),
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Text(
                                    text = bus.modelName,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 1
                                )

                                Text(
                                    text = "${bus.maxPowerHp} HP • ${bus.maxTorqueNm} Nm • ${(bus.grossWeightKg / 1000f).toInt()}t",
                                    fontSize = 10.sp,
                                    color = Color(0xFF90A4AE)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. LED Matrix Destination Sign Designer
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101722)),
                border = BorderStroke(1.dp, Color(0xFF233247)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "LED MATRIX DESTINATION SIGN STUDIO",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF90A4AE)
                    )

                    // Dot Matrix Screen Preview
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF050505))
                            .border(1.dp, Color(0xFF333333), RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "[$matrixLine] $matrixDest",
                            color = Color(0xFFFFB300),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 2.sp
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = matrixLine,
                            onValueChange = { matrixLine = it },
                            label = { Text("Line #", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(0.35f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF00E5FF),
                                unfocusedBorderColor = Color(0xFF2C3C54),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        OutlinedTextField(
                            value = matrixDest,
                            onValueChange = { matrixDest = it },
                            label = { Text("Destination Text", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(0.65f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF00E5FF),
                                unfocusedBorderColor = Color(0xFF2C3C54),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        // 3. Powertrain & Engine Dyno Swaps
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101722)),
                border = BorderStroke(1.dp, Color(0xFF233247)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "POWERTRAIN & ENGINE SWAP",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF90A4AE)
                    )

                    listOf(
                        Triple("Diesel", "12.8L Inline-6 Turbo Diesel (480 HP / 2300 Nm)", "Peak torque @ 1100-1400 RPM"),
                        Triple("Electric", "Dual-Motor PMSM (550 kW / 3200 Nm)", "Zero-emission instant flat torque"),
                        Triple("CNG", "Compressed Natural Gas Euro VI (340 HP / 1500 Nm)", "Low noise stoichiometric clean combustion"),
                        Triple("Hybrid", "Parallel Hybrid Eco (390 HP / 1900 Nm)", "Regenerative braking battery recovery")
                    ).forEach { (type, spec, desc) ->
                        val isSel = powertrain == type
                        Surface(
                            onClick = { powertrain = type },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) Color(0xFF1A334B) else Color(0xFF141C28),
                            border = BorderStroke(1.dp, if (isSel) Color(0xFF00E5FF) else Color(0xFF233247)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = type.uppercase(),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) Color(0xFF00E5FF) else Color.White
                                    )
                                    Text(
                                        text = if (isSel) "EQUIPPED" else "SWAP",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) Color(0xFF00E676) else Color(0xFF90A4AE)
                                    )
                                }
                                Text(text = spec, fontSize = 11.sp, color = Color.White)
                                Text(text = desc, fontSize = 10.sp, color = Color(0xFF90A4AE))
                            }
                        }
                    }
                }
            }
        }

        // 4. Air Suspension & Chassis Dynamics Tuning
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101722)),
                border = BorderStroke(1.dp, Color(0xFF233247)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "AIR SUSPENSION & ECAS TUNING",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF90A4AE)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Air Bag Damping Stiffness", fontSize = 12.sp, color = Color.White)
                        Text(
                            text = "${"%.2f".format(stiffness)}x",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF00E5FF)
                        )
                    }

                    Slider(
                        value = stiffness,
                        onValueChange = { stiffness = it },
                        valueRange = 0.8f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00E5FF),
                            activeTrackColor = Color(0xFF00E5FF),
                            inactiveTrackColor = Color(0xFF2C3C54)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Soft Comfort (0.8x)", fontSize = 10.sp, color = Color(0xFF90A4AE))
                        Text(text = "Firm Anti-Roll (1.5x)", fontSize = 10.sp, color = Color(0xFF90A4AE))
                    }
                }
            }
        }

        // 5. Exterior Paint Studio
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101722)),
                border = BorderStroke(1.dp, Color(0xFF233247)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "EXTERIOR LIVERY & PAINT",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF90A4AE)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf(
                            "#00E5FF" to "Cyan",
                            "#00E676" to "Green",
                            "#FFB300" to "Amber",
                            "#B388FF" to "Purple",
                            "#E53935" to "Red",
                            "#FFFFFF" to "White"
                        ).forEach { (hex, name) ->
                            val isColorSel = paintColor.equals(hex, ignoreCase = true)
                            val c = try { Color(android.graphics.Color.parseColor(hex)) } catch (e: Exception) { Color.Cyan }
                            Surface(
                                onClick = { paintColor = hex },
                                shape = CircleShape,
                                color = c,
                                border = BorderStroke(if (isColorSel) 3.dp else 1.dp, if (isColorSel) Color.White else Color.Transparent),
                                modifier = Modifier.size(38.dp)
                            ) {}
                        }
                    }
                }
            }
        }

        // 6. Save & Apply Button
        item {
            Button(
                onClick = {
                    viewModel.updateBusCustomization(
                        bus = selectedBus,
                        powertrain = powertrain,
                        colorHex = paintColor,
                        matrixLine = matrixLine,
                        matrixDest = matrixDest,
                        stiffness = stiffness
                    )
                },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_save_tuning")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Save, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "APPLY TUNING TO FLEET", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
