package com.example.bussim.ui

import android.annotation.SuppressLint
import android.graphics.Color as AndroidColor
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.bussim.viewmodel.BusSimulatorViewModel
import com.example.bussim.viewmodel.SimulatorUiState
import com.example.bussim.world.WorldCity
import com.example.bussim.world.WorldRouteCatalog
import java.util.Locale

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WorldDriveScreen(
    viewModel: BusSimulatorViewModel,
    state: SimulatorUiState
) {
    var originMenu by remember { mutableStateOf(false) }
    var destinationMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("WORLD DRIVE", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Live road routing • OpenStreetMap • OSRM • traffic & pedestrian simulation",
                    style = MaterialTheme.typography.bodySmall
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedButton(onClick = { originMenu = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("${state.worldOrigin.city}, ${state.worldOrigin.country}")
                        }
                        DropdownMenu(expanded = originMenu, onDismissRequest = { originMenu = false }) {
                            LazyColumn(modifier = Modifier.height(360.dp)) {
                                items(WorldRouteCatalog.cities) { city ->
                                    DropdownMenuItem(
                                        text = { Text("${city.city} • ${city.country}") },
                                        onClick = {
                                            viewModel.setWorldOrigin(city)
                                            originMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedButton(onClick = { destinationMenu = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("${state.worldDestination.city}, ${state.worldDestination.country}")
                        }
                        DropdownMenu(expanded = destinationMenu, onDismissRequest = { destinationMenu = false }) {
                            LazyColumn(modifier = Modifier.height(360.dp)) {
                                items(WorldRouteCatalog.cities) { city ->
                                    DropdownMenuItem(
                                        text = { Text("${city.city} • ${city.country}") },
                                        onClick = {
                                            viewModel.setWorldDestination(city)
                                            destinationMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                    Button(
                        onClick = { viewModel.planWorldRoute() },
                        enabled = !state.worldRouteLoading,
                        modifier = Modifier.width(110.dp)
                    ) {
                        if (state.worldRouteLoading) CircularProgressIndicator(modifier = Modifier.width(18.dp))
                        else Text("PLAN")
                    }
                }
                state.worldRouteError?.let {
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
                if (state.worldRoute != null) {
                    val km = state.worldDistanceMeters / 1000.0
                    val hours = state.worldEtaSeconds / 3600.0
                    Text(
                        String.format(
                            Locale.US,
                            "Route: %.1f km • road ETA %.1f h • %d pedestrians • dynamic traffic",
                            km, hours, state.pedestrianCount
                        ),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        WorldMapView(
            modifier = Modifier.fillMaxSize(),
            state = state
        )
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun WorldMapView(
    modifier: Modifier,
    state: SimulatorUiState
) {
    val html = remember(state.worldRoute, state.worldOrigin, state.worldDestination, state.trafficVehicles, state.pedestrianCount) {
        buildMapHtml(state)
    }

    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(context).apply {
                setBackgroundColor(AndroidColor.rgb(7, 11, 16))
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                webViewClient = WebViewClient()
                loadDataWithBaseURL(
                    "https://www.openstreetmap.org/",
                    html,
                    "text/html",
                    "UTF-8",
                    null
                )
            }
        },
        update = { webView ->
            webView.loadDataWithBaseURL(
                "https://www.openstreetmap.org/",
                html,
                "text/html",
                "UTF-8",
                null
            )
        }
    )
}

private fun buildMapHtml(state: SimulatorUiState): String {
    val origin = state.worldOrigin
    val destination = state.worldDestination
    val route = state.worldRoute?.geometry.orEmpty()
    val routeJs = route.joinToString(",") { "[${it.first},${it.second}]" }

    return """
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<style>
html,body,#map{height:100%;margin:0;background:#070b10}
.leaflet-control-attribution{font-size:9px}
.panel{position:absolute;z-index:9999;top:10px;left:10px;background:rgba(7,11,16,.88);color:#fff;padding:8px 10px;border-radius:8px;font:12px sans-serif}
</style>
</head>
<body>
<div id="map"></div>
<div class="panel">OMNIBUS PRO • REAL WORLD ROAD MODE</div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const map=L.map('map',{zoomControl:true}).setView([${origin.latitude},${origin.longitude}],6);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
 maxZoom:19,attribution:'© OpenStreetMap contributors'
}).addTo(map);

const origin=L.marker([${origin.latitude},${origin.longitude}]).addTo(map)
 .bindPopup('<b>DEPOT / ORIGIN</b><br>${escapeJs(origin.city)}, ${escapeJs(origin.country)}');
const destination=L.marker([${destination.latitude},${destination.longitude}]).addTo(map)
 .bindPopup('<b>TERMINAL / DESTINATION</b><br>${escapeJs(destination.city)}, ${escapeJs(destination.country)}');

const route=[${routeJs}];
if(route.length>1){
 const line=L.polyline(route,{weight:6,opacity:.9}).addTo(map);
 map.fitBounds(line.getBounds().pad(.08));
 // Simulated bus position on route.
 const bus=L.circleMarker(route[Math.floor(route.length*.32)],{
   radius:9,weight:3
 }).addTo(map).bindTooltip('PLAYER BUS',{permanent:true,direction:'top'});
 // Traffic and pedestrian actors are represented on the actual road corridor.
 for(let i=0;i<8;i++){
   const p=route[Math.floor((i+1)*route.length/9)];
   L.circleMarker(p,{radius:5,weight:1}).addTo(map).bindTooltip('Traffic AI');
 }
 for(let i=0;i<Math.min(${state.pedestrianCount},18);i++){
   const p=route[Math.floor((i+2)*route.length/20)];
   L.circleMarker(p,{radius:3,weight:1}).addTo(map).bindTooltip('Pedestrian');
 }
}
function escapeJs(s){return s.replaceAll('&','&amp;').replaceAll("'","&#39;").replaceAll('<','&lt;').replaceAll('>','&gt;')}
</script>
</body>
</html>
""".trimIndent()
}