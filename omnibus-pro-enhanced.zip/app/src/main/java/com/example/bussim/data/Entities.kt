package com.example.bussim.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bus_fleet")
data class BusFleetEntity(
    @PrimaryKey val id: String,
    val modelName: String,
    val type: String, // CityBus, Articulated, IntercityCoach
    val powertrain: String, // Diesel, Electric, Hybrid, CNG
    val transmission: String, // Auto_ZF, Manual_6, TraXon_AMT
    val maxPowerHp: Int,
    val maxTorqueNm: Int,
    val grossWeightKg: Float,
    val paintColorHex: String,
    val liveryStyle: String, // TransitStripes, ModernWave, CyberMinimal, MetroExpress
    val matrixLineNumber: String,
    val matrixDestination: String,
    val matrixLedColorHex: String,
    val suspensionHeightMm: Float, // -80 (kneel) to +60 (off-road clearance), 0 is nominal
    val suspensionStiffness: Float, // 0.8 to 1.5 multiplier
    val retarderStages: Int, // 2 to 5
    val mileageKm: Float,
    val fuelLevelPercent: Float,
    val isSelected: Boolean
)

@Entity(tableName = "route_history")
data class RouteHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val routeName: String,
    val stopsCompleted: Int,
    val totalStops: Int,
    val passengersTransported: Int,
    val passengerComfortRating: Float, // 0.0 - 100.0%
    val revenueEarned: Double,
    val energyUsed: Float,
    val timestamp: Long = System.currentTimeMillis()
)
