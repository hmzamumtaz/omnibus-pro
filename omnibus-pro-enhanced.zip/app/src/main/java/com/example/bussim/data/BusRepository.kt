package com.example.bussim.data

import kotlinx.coroutines.flow.Flow

class BusRepository(private val busDao: BusDao) {
    val allBuses: Flow<List<BusFleetEntity>> = busDao.getAllBuses()
    val selectedBus: Flow<BusFleetEntity?> = busDao.getSelectedBus()
    val allRouteHistories: Flow<List<RouteHistoryEntity>> = busDao.getAllRouteHistories()

    suspend fun selectBus(busId: String) {
        busDao.clearSelectedBuses()
        busDao.setSelectedBus(busId)
    }

    suspend fun updateBus(bus: BusFleetEntity) {
        busDao.updateBus(bus)
    }

    suspend fun saveRouteCompletion(history: RouteHistoryEntity) {
        busDao.insertRouteHistory(history)
    }

    suspend fun checkAndSeedIfNeeded() {
        if (busDao.getBusCount() == 0) {
            busDao.insertBuses(BusDatabase.getDefaultBuses())
        }
    }
}
