package com.example.bussim.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [BusFleetEntity::class, RouteHistoryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class BusDatabase : RoomDatabase() {
    abstract fun busDao(): BusDao

    companion object {
        @Volatile
        private var INSTANCE: BusDatabase? = null

        fun getDatabase(context: Context): BusDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BusDatabase::class.java,
                    "omnibus_simulator.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            INSTANCE?.busDao()?.insertBuses(getDefaultBuses())
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }

        fun getDefaultBuses(): List<BusFleetEntity> {
            return listOf(
                BusFleetEntity(
                    id = "BUS-01",
                    modelName = "Solaris Urbino 18 articulated",
                    type = "Articulated Low-Floor",
                    powertrain = "Diesel",
                    transmission = "Auto_ZF",
                    maxPowerHp = 480,
                    maxTorqueNm = 2300,
                    grossWeightKg = 28000f,
                    paintColorHex = "#00E5FF",
                    liveryStyle = "MetroExpress",
                    matrixLineNumber = "M42",
                    matrixDestination = "DOWNTOWN - WATERFRONT",
                    matrixLedColorHex = "#FFB300",
                    suspensionHeightMm = 0f,
                    suspensionStiffness = 1.0f,
                    retarderStages = 4,
                    mileageKm = 1420.5f,
                    fuelLevelPercent = 88.0f,
                    isSelected = true
                ),
                BusFleetEntity(
                    id = "BUS-02",
                    modelName = "BYD K9 Electric Rapid",
                    type = "CityBus 12m",
                    powertrain = "Electric",
                    transmission = "Auto_ZF",
                    maxPowerHp = 550,
                    maxTorqueNm = 3200,
                    grossWeightKg = 19500f,
                    paintColorHex = "#00E676",
                    liveryStyle = "ModernWave",
                    matrixLineNumber = "E7",
                    matrixDestination = "AIRPORT EXP - TERMINAL 3",
                    matrixLedColorHex = "#00E676",
                    suspensionHeightMm = 0f,
                    suspensionStiffness = 1.1f,
                    retarderStages = 5,
                    mileageKm = 890.0f,
                    fuelLevelPercent = 95.0f,
                    isSelected = false
                ),
                BusFleetEntity(
                    id = "BUS-03",
                    modelName = "MAN Lion's City 12G CNG",
                    type = "CityBus 12m",
                    powertrain = "CNG",
                    transmission = "TraXon_AMT",
                    maxPowerHp = 340,
                    maxTorqueNm = 1500,
                    grossWeightKg = 18700f,
                    paintColorHex = "#FFB300",
                    liveryStyle = "TransitStripes",
                    matrixLineNumber = "104",
                    matrixDestination = "TECH CAMPUS - EAST",
                    matrixLedColorHex = "#00E5FF",
                    suspensionHeightMm = 0f,
                    suspensionStiffness = 0.95f,
                    retarderStages = 4,
                    mileageKm = 3450.2f,
                    fuelLevelPercent = 74.0f,
                    isSelected = false
                ),
                BusFleetEntity(
                    id = "BUS-04",
                    modelName = "Mercedes Citaro C2 Hybrid",
                    type = "CityBus 12m",
                    powertrain = "Hybrid",
                    transmission = "Manual_6",
                    maxPowerHp = 390,
                    maxTorqueNm = 1900,
                    grossWeightKg = 19200f,
                    paintColorHex = "#B388FF",
                    liveryStyle = "CyberMinimal",
                    matrixLineNumber = "88B",
                    matrixDestination = "HARBOR VIEW - CIRCLE",
                    matrixLedColorHex = "#FFFFFF",
                    suspensionHeightMm = 0f,
                    suspensionStiffness = 1.05f,
                    retarderStages = 4,
                    mileageKm = 520.4f,
                    fuelLevelPercent = 91.0f,
                    isSelected = false
                ),
                BusFleetEntity(
                    id = "BUS-05",
                    modelName = "Volvo 9700 Long Haul",
                    type = "Intercity Coach 13m",
                    powertrain = "Diesel",
                    transmission = "TraXon_AMT",
                    maxPowerHp = 460,
                    maxTorqueNm = 2300,
                    grossWeightKg = 19500f,
                    paintColorHex = "#1565C0",
                    liveryStyle = "ModernWave",
                    matrixLineNumber = "EXP-1",
                    matrixDestination = "CAPITAL EXPRESS",
                    matrixLedColorHex = "#FFFFFF",
                    suspensionHeightMm = 0f,
                    suspensionStiffness = 1.0f,
                    retarderStages = 5,
                    mileageKm = 1220.0f,
                    fuelLevelPercent = 83.0f,
                    isSelected = false
                ),
                BusFleetEntity(
                    id = "BUS-06",
                    modelName = "Scania Touring HD",
                    type = "Intercity Coach 14m",
                    powertrain = "Diesel",
                    transmission = "TraXon_AMT",
                    maxPowerHp = 500,
                    maxTorqueNm = 2550,
                    grossWeightKg = 21000f,
                    paintColorHex = "#6A1B9A",
                    liveryStyle = "TransitStripes",
                    matrixLineNumber = "INT-7",
                    matrixDestination = "INTERNATIONAL TERMINAL",
                    matrixLedColorHex = "#FFB300",
                    suspensionHeightMm = 0f,
                    suspensionStiffness = 1.08f,
                    retarderStages = 5,
                    mileageKm = 740.0f,
                    fuelLevelPercent = 96.0f,
                    isSelected = false
                ),
                BusFleetEntity(
                    id = "BUS-07",
                    modelName = "Omnibus E18 Electric",
                    type = "Articulated Low-Floor",
                    powertrain = "Electric",
                    transmission = "Auto_ZF",
                    maxPowerHp = 610,
                    maxTorqueNm = 3500,
                    grossWeightKg = 29000f,
                    paintColorHex = "#00838F",
                    liveryStyle = "CyberMinimal",
                    matrixLineNumber = "E18",
                    matrixDestination = "ZERO EMISSION CORRIDOR",
                    matrixLedColorHex = "#00E676",
                    suspensionHeightMm = 0f,
                    suspensionStiffness = 1.12f,
                    retarderStages = 5,
                    mileageKm = 310.0f,
                    fuelLevelPercent = 100.0f,
                    isSelected = false
                )
            )
        }
    }
}
