package com.example.bussim.passenger

import kotlin.random.Random

enum class PassengerState {
    WAITING_AT_STOP,
    APPROACHING_DOOR,
    VALIDATING_TICKET,
    FINDING_SEAT,
    SEATED,
    REQUESTING_STOP,
    ALIGHTING,
    COMPLETED
}

enum class PassengerType(val label: String, val ticketType: String) {
    COMMUTER("Daily Commuter", "Monthly Pass"),
    STUDENT("University Student", "Youth Transit Card"),
    SENIOR("Senior Citizen", "Elderly Concession"),
    TOURIST("City Traveler", "Day Pass"),
    BUSINESS("Business Professional", "Contactless NFC")
}

data class PassengerAgent(
    val id: Int,
    val name: String,
    val type: PassengerType,
    var state: PassengerState = PassengerState.WAITING_AT_STOP,
    val destinationStopIndex: Int,
    var satisfactionPercent: Float = 100f,
    var currentSpeechBubble: String? = null,
    var speechTimerSec: Float = 0f,
    var seatNumber: Int = -1
)

class PassengerManager {
    val activePassengers = mutableListOf<PassengerAgent>()
    var totalPassengersServed: Int = 0
    var cumulativeRevenue: Double = 0.0
    var stopRequestedChime: Boolean = false

    // Pool of names
    private val firstNames = listOf("Alex", "Sophia", "Marcus", "Elena", "Liam", "Maya", "Daniel", "Chloe", "David", "Zara", "Vikram", "Amara")

    fun spawnBoardingBatch(count: Int, currentStopIndex: Int, totalRouteStops: Int) {
        val types = PassengerType.values()
        for (i in 0 until count) {
            val destIndex = Random.nextInt(currentStopIndex + 1, totalRouteStops + 1)
            val agent = PassengerAgent(
                id = totalPassengersServed + activePassengers.size + 1,
                name = firstNames.random(),
                type = types.random(),
                state = PassengerState.APPROACHING_DOOR,
                destinationStopIndex = destIndex,
                seatNumber = activePassengers.size + 1
            )
            activePassengers.add(agent)
        }
    }

    fun updateTick(
        dt: Float,
        currentJerkMs3: Float,
        lateralG: Float,
        speedKmh: Float,
        doorsOpen: Boolean,
        isKneeling: Boolean,
        farePerPassenger: Double
    ) {
        val harshRide = kotlin.math.abs(currentJerkMs3) > 2.8f || kotlin.math.abs(lateralG) > 0.35f
        val smoothRide = speedKmh > 20f && kotlin.math.abs(currentJerkMs3) < 0.8f && kotlin.math.abs(lateralG) < 0.12f

        activePassengers.forEach { p ->
            // Speech timer
            if (p.speechTimerSec > 0f) {
                p.speechTimerSec -= dt
                if (p.speechTimerSec <= 0f) {
                    p.currentSpeechBubble = null
                }
            }

            when (p.state) {
                PassengerState.APPROACHING_DOOR -> {
                    if (doorsOpen) {
                        p.state = PassengerState.VALIDATING_TICKET
                        if (isKneeling && Random.nextFloat() < 0.25f) {
                            p.currentSpeechBubble = "Thanks for kneeling the bus!"
                            p.speechTimerSec = 3f
                        }
                    }
                }
                PassengerState.VALIDATING_TICKET -> {
                    // Quick ticket tap animation
                    p.state = PassengerState.FINDING_SEAT
                    totalPassengersServed++
                    cumulativeRevenue += farePerPassenger
                }
                PassengerState.FINDING_SEAT -> {
                    p.state = PassengerState.SEATED
                }
                PassengerState.SEATED -> {
                    if (harshRide) {
                        p.satisfactionPercent = (p.satisfactionPercent - 4f).coerceAtLeast(20f)
                        if (p.currentSpeechBubble == null && Random.nextFloat() < 0.15f) {
                            p.currentSpeechBubble = listOf(
                                "Whoa, watch the brakes!",
                                "Hold on tight!",
                                "That was a sharp turn!",
                                "Careful with the steering!"
                            ).random()
                            p.speechTimerSec = 3.5f
                        }
                    } else if (smoothRide && Random.nextFloat() < 0.03f && p.currentSpeechBubble == null) {
                        p.currentSpeechBubble = listOf(
                            "Very smooth ride today!",
                            "Great driving driver.",
                            "Right on schedule!"
                        ).random()
                        p.speechTimerSec = 3.0f
                    }
                }
                PassengerState.REQUESTING_STOP -> {
                    if (doorsOpen && speedKmh < 1f) {
                        p.state = PassengerState.ALIGHTING
                    }
                }
                PassengerState.ALIGHTING -> {
                    p.state = PassengerState.COMPLETED
                }
                else -> {}
            }
        }

        // Clean up completed passengers
        activePassengers.removeAll { it.state == PassengerState.COMPLETED }
    }

    fun prepareForStop(stopIndex: Int) {
        activePassengers.forEach { p ->
            if (p.destinationStopIndex <= stopIndex && p.state == PassengerState.SEATED) {
                p.state = PassengerState.REQUESTING_STOP
                stopRequestedChime = true
                p.currentSpeechBubble = "Stop requested!"
                p.speechTimerSec = 3f
            }
        }
    }

    fun getAverageSatisfaction(): Float {
        if (activePassengers.isEmpty()) return 98.5f
        return activePassengers.map { it.satisfactionPercent }.average().toFloat()
    }
}
