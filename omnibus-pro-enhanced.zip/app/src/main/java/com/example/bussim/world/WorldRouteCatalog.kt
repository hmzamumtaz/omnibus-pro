package com.example.bussim.world

data class WorldCity(
    val id: String,
    val city: String,
    val country: String,
    val latitude: Double,
    val longitude: Double
)

data class WorldRoutePreset(
    val id: String,
    val name: String,
    val origin: WorldCity,
    val destination: WorldCity,
    val category: String
)

object WorldRouteCatalog {
    val cities = listOf(
        WorldCity("LHE","Lahore","Pakistan",31.5204,74.3587),
        WorldCity("ISB","Islamabad","Pakistan",33.6844,73.0479),
        WorldCity("OKA","Okara","Pakistan",30.8138,73.4534),
        WorldCity("KHI","Karachi","Pakistan",24.8607,67.0011),
        WorldCity("DXB","Dubai","United Arab Emirates",25.2048,55.2708),
        WorldCity("DOH","Doha","Qatar",25.2854,51.5310),
        WorldCity("IST","Istanbul","Türkiye",41.0082,28.9784),
        WorldCity("ATH","Athens","Greece",37.9838,23.7275),
        WorldCity("BER","Berlin","Germany",52.5200,13.4050),
        WorldCity("PAR","Paris","France",48.8566,2.3522),
        WorldCity("LON","London","United Kingdom",51.5074,-0.1278),
        WorldCity("AMS","Amsterdam","Netherlands",52.3676,4.9041),
        WorldCity("STO","Stockholm","Sweden",59.3293,18.0686),
        WorldCity("OSL","Oslo","Norway",59.9139,10.7522),
        WorldCity("ROM","Rome","Italy",41.9028,12.4964),
        WorldCity("MAD","Madrid","Spain",40.4168,-3.7038),
        WorldCity("LIS","Lisbon","Portugal",38.7223,-9.1393),
        WorldCity("NYC","New York","United States",40.7128,-74.0060),
        WorldCity("WDC","Washington, D.C.","United States",38.9072,-77.0369),
        WorldCity("TOR","Toronto","Canada",43.6532,-79.3832),
        WorldCity("TYO","Tokyo","Japan",35.6762,139.6503),
        WorldCity("SYD","Sydney","Australia",-33.8688,151.2093),
        WorldCity("CPT","Cape Town","South Africa",-33.9249,18.4241),
        WorldCity("CAI","Cairo","Egypt",30.0444,31.2357),
        WorldCity("BRU","Brussels","Belgium",50.8503,4.3517),
        WorldCity("PRG","Prague","Czechia",50.0755,14.4378),
        WorldCity("VIE","Vienna","Austria",48.2082,16.3738),
        WorldCity("BUD","Budapest","Hungary",47.4979,19.0402)
    )

    val presets: List<WorldRoutePreset> = listOf(
        WorldRoutePreset("PK-01","Okara → Lahore",city("OKA"),city("LHE"),"Domestic"),
        WorldRoutePreset("PK-02","Lahore → Islamabad",city("LHE"),city("ISB"),"Domestic"),
        WorldRoutePreset("PK-03","Lahore → Karachi",city("LHE"),city("KHI"),"Domestic"),
        WorldRoutePreset("INT-01","Lahore → Dubai",city("LHE"),city("DXB"),"International"),
        WorldRoutePreset("INT-02","Istanbul → Berlin",city("IST"),city("BER"),"International"),
        WorldRoutePreset("INT-03","Paris → Amsterdam",city("PAR"),city("AMS"),"International"),
        WorldRoutePreset("INT-04","London → Paris",city("LON"),city("PAR"),"International"),
        WorldRoutePreset("INT-05","Berlin → Stockholm",city("BER"),city("STO"),"International"),
        WorldRoutePreset("INT-06","New York → Washington",city("NYC"),city("WDC"),"International"),
        WorldRoutePreset("INT-07","Toronto → New York",city("TOR"),city("NYC"),"International"),
        WorldRoutePreset("INT-08","Madrid → Lisbon",city("MAD"),city("LIS"),"International"),
        WorldRoutePreset("INT-09","Rome → Athens",city("ROM"),city("ATH"),"International"),
        WorldRoutePreset("INT-10","Cairo → Istanbul",city("CAI"),city("IST"),"International"),
        WorldRoutePreset("INT-11","Berlin → Prague",city("BER"),city("PRG"),"International"),
        WorldRoutePreset("INT-12","Vienna → Budapest",city("VIE"),city("BUD"),"International"),
        WorldRoutePreset("INT-13","Paris → Brussels",city("PAR"),city("BRU"),"International")
    )

    private fun city(id: String): WorldCity =
        cities.first { it.id == id }
}