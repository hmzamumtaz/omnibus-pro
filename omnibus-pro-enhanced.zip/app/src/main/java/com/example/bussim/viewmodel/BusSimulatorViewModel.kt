package com.example.bussim.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.bussim.architecture.ArchitectureBlueprintData
import com.example.bussim.architecture.ArchitectureFile
import com.example.bussim.data.BusDatabase
import com.example.bussim.data.BusFleetEntity
import com.example.bussim.data.BusRepository
import com.example.bussim.data.RouteHistoryEntity
import com.example.bussim.passenger.PassengerAgent
import com.example.bussim.passenger.PassengerManager
import com.example.bussim.physics.PacejkaTireModel
import com.example.bussim.physics.PowertrainType
import com.example.bussim.physics.VehiclePhysicsEngine
import com.example.bussim.physics.VehicleTelemetry
import com.example.bussim.world.BusStop
import com.example.bussim.world.EnvironmentController
import com.example.bussim.world.RouteDefinition
import com.example.bussim.world.RouteManager
import com.example.bussim.world.TrafficSimulation
import com.example.bussim.world.TrafficVehicle
import com.example.bussim.world.WeatherCondition
import com.example.bussim.world.PedestrianSimulation
import com.example.bussim.world.WorldCity
import com.example.bussim.world.WorldRouteResult
import com.example.bussim.world.WorldRouteService
import com.example.bussim.world.WorldRouteCatalog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

enum class CameraView {
    COCKPIT,
    CHASE_3D,
    PASSENGER_CCTV,
    SUSPENSION_CHASSIS
}

data class SimulatorUiState(
    val telemetry: VehicleTelemetry = VehicleTelemetry(),
    val cameraView: CameraView = CameraView.COCKPIT,
    val selectedBus: BusFleetEntity? = null,
    val allBuses: List<BusFleetEntity> = emptyList(),
    val currentRoute: RouteDefinition? = null,
    val nextStop: BusStop? = null,
    val distanceToNextStopM: Float = 0f,
    val isAtStop: Boolean = false,
    val activePassengers: List<PassengerAgent> = emptyList(),
    val averageSatisfaction: Float = 98.5f,
    val stopRequestedChime: Boolean = false,
    val weather: WeatherCondition = WeatherCondition.CLEAR_SUNNY,
    val timeOfDayHours: Float = 14.5f,
    val trafficVehicles: List<TrafficVehicle> = emptyList(),
    val steeringInput: Float = 0f,
    val throttleInput: Float = 0f,
    val brakeInput: Float = 0f,
    val eventNotification: String? = null,
    val selectedArchFile: ArchitectureFile = ArchitectureBlueprintData.files.first(),
    val routeHistories: List<RouteHistoryEntity> = emptyList(),
    val worldOrigin: WorldCity = WorldRouteCatalog.cities.first { it.id == "OKA" },
    val worldDestination: WorldCity = WorldRouteCatalog.cities.first { it.id == "LHE" },
    val worldRoute: WorldRouteResult? = null,
    val worldRouteLoading: Boolean = false,
    val worldRouteError: String? = null,
    val worldDistanceMeters: Double = 0.0,
    val worldEtaSeconds: Double = 0.0,
    val pedestrianCount: Int = 0
)

class BusSimulatorViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: BusRepository
    val physicsEngine = VehiclePhysicsEngine()
    val environment = EnvironmentController()
    val routeManager = RouteManager()
    val trafficSimulation = TrafficSimulation()
    val passengerManager = PassengerManager()
    val pedestrianSimulation = PedestrianSimulation()
    private val worldRouteService = WorldRouteService()

    private val _uiState = MutableStateFlow(SimulatorUiState())
    val uiState: StateFlow<SimulatorUiState> = _uiState.asStateFlow()

    private var currentSteering = 0f
    private var currentThrottle = 0f
    private var currentBrake = 0f

    init {
        val db = BusDatabase.getDatabase(application)
        repository = BusRepository(db.busDao())

        viewModelScope.launch(Dispatchers.IO) {
            repository.checkAndSeedIfNeeded()
        }

        // Observe buses from Room
        viewModelScope.launch {
            repository.allBuses.collectLatest { buses ->
                val selected = buses.find { it.isSelected } ?: buses.firstOrNull()
                _uiState.value = _uiState.value.copy(
                    allBuses = buses,
                    selectedBus = selected
                )
                selected?.let { applyBusConfig(it) }
            }
        }

        // Observe route history
        viewModelScope.launch {
            repository.allRouteHistories.collectLatest { histories ->
                _uiState.value = _uiState.value.copy(routeHistories = histories)
            }
        }

        // Initial setup
        passengerManager.spawnBoardingBatch(14, 0, routeManager.activeRoute.stops.size)
        pedestrianSimulation.seed(24)
        startSimulationLoop()
    }

    private fun applyBusConfig(bus: BusFleetEntity) {
        physicsEngine.drivetrain.powertrainType = when (bus.powertrain) {
            "Electric" -> PowertrainType.ELECTRIC
            "CNG" -> PowertrainType.CNG
            "Hybrid" -> PowertrainType.HYBRID
            else -> PowertrainType.DIESEL
        }
        physicsEngine.emptyMassKg = bus.grossWeightKg * 0.75f
        physicsEngine.suspension.stiffnessMultiplier = bus.suspensionStiffness
        physicsEngine.suspension.nominalHeightMm = bus.suspensionHeightMm
    }

    private fun startSimulationLoop() {
        viewModelScope.launch(Dispatchers.Default) {
            var lastTime = System.nanoTime()
            while (isActive) {
                val now = System.nanoTime()
                val dt = ((now - lastTime) / 1_000_000_000f).coerceIn(0.005f, 0.05f)
                lastTime = now

                // Update world & environment
                environment.update(dt)
                physicsEngine.currentSurface = environment.state.weather.surfaceType
                physicsEngine.waterDepthMm = environment.state.weather.waterDepthMm

                // Step physics engine
                physicsEngine.passengerCount = passengerManager.activePassengers.size
                val telemetry = physicsEngine.updateTick(
                    dt = dt,
                    throttleInput = currentThrottle,
                    brakePedalInput = currentBrake,
                    steeringWheelNormalized = currentSteering
                )

                // Step AI traffic and world pedestrians
                trafficSimulation.update(dt, telemetry.speedKmh)
                pedestrianSimulation.update(dt)

                // Step Passenger AI
                passengerManager.updateTick(
                    dt = dt,
                    currentJerkMs3 = telemetry.jerkMs3,
                    lateralG = telemetry.lateralG,
                    speedKmh = telemetry.speedKmh,
                    doorsOpen = telemetry.door1Open || telemetry.door2Open,
                    isKneeling = telemetry.isKneeling,
                    farePerPassenger = routeManager.activeRoute.baseFarePerPassenger
                )

                // Check stop distance
                val distToStop = routeManager.getDistanceToNextStop(telemetry.distanceDrivenMeters)
                val atStop = routeManager.isAtStop(telemetry.distanceDrivenMeters, telemetry.speedKmh)

                if (distToStop in 0f..80f && !passengerManager.stopRequestedChime) {
                    passengerManager.prepareForStop(routeManager.currentStopIndex)
                }

                // Air purge notification & audio
                var eventText: String? = _uiState.value.eventNotification
                if (physicsEngine.brakes.hasPurgedAir) {
                    physicsEngine.brakes.hasPurgedAir = false
                    eventText = "Compressor Governor Cut-out: Air Purged (10.5 bar)"
                    com.example.bussim.audio.CockpitAudioEngine.playAirPurge(viewModelScope)
                } else if (telemetry.isJackknifed) {
                    eventText = "CRITICAL: Semi-Trailer Jackknife Detected!"
                    com.example.bussim.audio.CockpitAudioEngine.playLowAirAlarm(viewModelScope)
                } else if (telemetry.isHydroplaning) {
                    eventText = "WARNING: Hydroplaning Detected! Grip reduced."
                } else if (physicsEngine.brakes.isLowAirAlarmActive) {
                    eventText = "CAUTION: Low Air Pressure (< 6.0 bar)!"
                }

                _uiState.value = _uiState.value.copy(
                    telemetry = telemetry,
                    currentRoute = routeManager.activeRoute,
                    nextStop = routeManager.nextStop,
                    distanceToNextStopM = distToStop,
                    isAtStop = atStop,
                    activePassengers = passengerManager.activePassengers.toList(),
                    averageSatisfaction = passengerManager.getAverageSatisfaction(),
                    stopRequestedChime = passengerManager.stopRequestedChime,
                    weather = environment.state.weather,
                    timeOfDayHours = environment.state.timeOfDayHours,
                    trafficVehicles = trafficSimulation.vehicles.toList(),
                    steeringInput = currentSteering,
                    throttleInput = currentThrottle,
                    brakeInput = currentBrake,
                    eventNotification = eventText,
                    pedestrianCount = pedestrianSimulation.pedestrians.size
                )

                delay(16) // ~60 FPS
            }
        }
    }

    // Driver control handlers
    fun setSteering(value: Float) {
        currentSteering = value.coerceIn(-1f, 1f)
    }

    fun setThrottle(value: Float) {
        currentThrottle = value.coerceIn(0f, 1f)
    }

    fun setBrake(value: Float) {
        currentBrake = value.coerceIn(0f, 1f)
    }

    fun setGearMode(mode: String) {
        physicsEngine.drivetrain.gearMode = mode
    }

    fun cycleRetarder() {
        val level = physicsEngine.brakes.cycleRetarder()
        if (level > 0) {
            com.example.bussim.audio.CockpitAudioEngine.playRetarderWhine(viewModelScope)
        }
    }

    fun cycleJakeBrake() {
        val stage = physicsEngine.brakes.cycleJakeBrake()
        if (stage > 0) {
            com.example.bussim.audio.CockpitAudioEngine.playJakeBrakeRattle(viewModelScope)
        }
    }

    fun toggleParkingBrake() {
        physicsEngine.brakes.toggleParkingBrake()
        com.example.bussim.audio.CockpitAudioEngine.playAirPurge(viewModelScope)
    }

    fun toggleTrailerSupplyValve() {
        physicsEngine.brakes.toggleTrailerSupplyValve()
        com.example.bussim.audio.CockpitAudioEngine.playAirPurge(viewModelScope)
    }

    fun toggleKneeling() {
        physicsEngine.suspension.toggleKneel()
        com.example.bussim.audio.CockpitAudioEngine.playAirPurge(viewModelScope)
    }

    fun toggleDoor1() {
        physicsEngine.toggleDoor1()
        com.example.bussim.audio.CockpitAudioEngine.playAirPurge(viewModelScope)
        checkStopBoarding()
    }

    fun toggleDoor2() {
        physicsEngine.toggleDoor2()
        com.example.bussim.audio.CockpitAudioEngine.playAirPurge(viewModelScope)
        checkStopBoarding()
    }

    fun blastHorn() {
        com.example.bussim.audio.CockpitAudioEngine.playAirHorn(viewModelScope)
    }

    fun toggleVehicleCategory() {
        physicsEngine.toggleVehicleCategory()
        com.example.bussim.audio.CockpitAudioEngine.playAirPurge(viewModelScope)
    }

    fun toggleSplitter() {
        physicsEngine.drivetrain.toggleSplitter()
    }

    fun toggleRange() {
        physicsEngine.drivetrain.toggleRange()
    }

    fun toggleDiffLock() {
        physicsEngine.drivetrain.toggleDiffLock()
    }

    fun toggleAc() {
        physicsEngine.toggleAc()
    }

    fun setSunBlind(position: Float) {
        physicsEngine.sunBlindPosition = position.coerceIn(0f, 1f)
    }

    private fun checkStopBoarding() {
        if (_uiState.value.isAtStop && (physicsEngine.door1Open || physicsEngine.door2Open)) {
            val stop = routeManager.nextStop
            if (stop != null && !stop.isCompleted) {
                // Board waiting passengers
                passengerManager.spawnBoardingBatch(stop.waitingPassengers, routeManager.currentStopIndex, routeManager.activeRoute.stops.size)
                routeManager.markStopCompleted()
                passengerManager.stopRequestedChime = false

                // If completed all stops
                if (routeManager.nextStop == null) {
                    saveRouteCompleted()
                }
            }
        }
    }

    private fun saveRouteCompleted() {
        viewModelScope.launch(Dispatchers.IO) {
            val active = routeManager.activeRoute
            val history = RouteHistoryEntity(
                routeName = active.title,
                stopsCompleted = active.stops.size,
                totalStops = active.stops.size,
                passengersTransported = passengerManager.totalPassengersServed,
                passengerComfortRating = passengerManager.getAverageSatisfaction(),
                revenueEarned = passengerManager.cumulativeRevenue,
                energyUsed = 18.4f
            )
            repository.saveRouteCompletion(history)
        }
    }

    fun cycleWipers() {
        physicsEngine.wiperSpeed = (physicsEngine.wiperSpeed + 1) % 4
        physicsEngine.wipersActive = (physicsEngine.wiperSpeed > 0)
    }

    fun toggleHeadlights() {
        physicsEngine.headlightsOn = !physicsEngine.headlightsOn
    }

    fun toggleHazardLights() {
        physicsEngine.hazardLightsOn = !physicsEngine.hazardLightsOn
    }

    fun toggleJakeBrake() {
        cycleJakeBrake()
    }

    fun setCameraView(view: CameraView) {
        _uiState.value = _uiState.value.copy(cameraView = view)
    }

    fun setWeather(condition: WeatherCondition) {
        environment.setWeather(condition)
    }


    fun setWorldOrigin(city: WorldCity) {
        _uiState.value = _uiState.value.copy(worldOrigin = city, worldRoute = null, worldRouteError = null)
    }

    fun setWorldDestination(city: WorldCity) {
        _uiState.value = _uiState.value.copy(worldDestination = city, worldRoute = null, worldRouteError = null)
    }

    fun planWorldRoute() {
        val origin = _uiState.value.worldOrigin
        val destination = _uiState.value.worldDestination
        if (origin.id == destination.id) {
            _uiState.value = _uiState.value.copy(worldRouteError = "Choose two different cities.")
            return
        }
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(worldRouteLoading = true, worldRouteError = null)
            val result = worldRouteService.route(origin, destination)
            result.onSuccess { route ->
                _uiState.value = _uiState.value.copy(
                    worldRoute = route,
                    worldRouteLoading = false,
                    worldDistanceMeters = route.distanceMeters,
                    worldEtaSeconds = route.durationSeconds
                )
            }.onFailure { error ->
                _uiState.value = _uiState.value.copy(
                    worldRouteLoading = false,
                    worldRouteError = error.message ?: "Could not calculate route."
                )
            }
        }
    }

    fun selectRoute(index: Int) {
        routeManager.selectRoute(index)
        passengerManager.activePassengers.clear()
        passengerManager.spawnBoardingBatch(10, 0, routeManager.activeRoute.stops.size)
        physicsEngine.distanceDrivenM = 0f
    }

    fun selectBus(busId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.selectBus(busId)
        }
    }

    fun updateBusCustomization(
        bus: BusFleetEntity,
        powertrain: String,
        colorHex: String,
        matrixLine: String,
        matrixDest: String,
        stiffness: Float
    ) {
        val updated = bus.copy(
            powertrain = powertrain,
            paintColorHex = colorHex,
            matrixLineNumber = matrixLine,
            matrixDestination = matrixDest,
            suspensionStiffness = stiffness
        )
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateBus(updated)
        }
    }

    fun selectArchFile(file: ArchitectureFile) {
        _uiState.value = _uiState.value.copy(selectedArchFile = file)
    }

    fun clearEventNotification() {
        _uiState.value = _uiState.value.copy(eventNotification = null)
    }
}
