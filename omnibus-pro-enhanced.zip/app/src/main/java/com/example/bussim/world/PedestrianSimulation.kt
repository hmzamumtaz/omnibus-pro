package com.example.bussim.world

import kotlin.math.abs
import kotlin.random.Random

enum class PedestrianState { WAITING, WALKING, CROSSING, BOARDING }

data class WorldPedestrian(
    val id: Int,
    var progress: Float,
    var laneOffset: Float,
    val state: PedestrianState,
    val walkingSpeedMps: Float
)

class PedestrianSimulation {
    val pedestrians = mutableListOf<WorldPedestrian>()
    private var nextId = 1

    fun seed(count: Int = 18) {
        if (pedestrians.isNotEmpty()) return
        repeat(count) {
            pedestrians += WorldPedestrian(
                id = nextId++,
                progress = Random.nextFloat(),
                laneOffset = Random.nextFloat() * 2f - 1f,
                state = PedestrianState.values().random(),
                walkingSpeedMps = 0.8f + Random.nextFloat() * 1.0f
            )
        }
    }

    fun update(dt: Float) {
        pedestrians.forEach {
            if (it.state == PedestrianState.WALKING || it.state == PedestrianState.CROSSING) {
                it.progress = (it.progress + dt * it.walkingSpeedMps / 180f) % 1f
            }
        }
    }

    fun nearby(progress: Float): List<WorldPedestrian> =
        pedestrians.filter { abs(it.progress - progress) < 0.12f }
}