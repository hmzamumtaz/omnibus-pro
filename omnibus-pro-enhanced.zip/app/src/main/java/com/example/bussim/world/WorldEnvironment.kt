package com.example.bussim.world

import com.example.bussim.physics.PacejkaTireModel

enum class WeatherCondition(
    val displayName: String,
    val surfaceType: PacejkaTireModel.SurfaceType,
    val waterDepthMm: Float,
    val fogDensity: Float, // 0.0 = clear, 1.0 = heavy fog
    val isRaining: Boolean,
    val isSnowing: Boolean
) {
    CLEAR_SUNNY("Clear Sky", PacejkaTireModel.SurfaceType.DRY_ASPHALT, 0.0f, 0.0f, false, false),
    OVERCAST_DUSK("Overcast Dusk", PacejkaTireModel.SurfaceType.DRY_ASPHALT, 0.0f, 0.05f, false, false),
    FOGGY_VALLEY("Dense Valley Fog", PacejkaTireModel.SurfaceType.WET_TAR, 0.4f, 0.75f, false, false),
    LIGHT_RAIN("Light Rain", PacejkaTireModel.SurfaceType.WET_TAR, 1.2f, 0.15f, true, false),
    TORRENTIAL_DOWNPOUR("Torrential Downpour", PacejkaTireModel.SurfaceType.WET_TAR, 3.2f, 0.40f, true, false),
    THUNDERSTORM("Heavy Thunderstorm", PacejkaTireModel.SurfaceType.WET_TAR, 4.0f, 0.45f, true, false),
    BLIZZARD_ICE("Blizzard & Black Ice", PacejkaTireModel.SurfaceType.BLACK_ICE, 2.5f, 0.65f, false, true)
}

data class EnvironmentState(
    val timeOfDayHours: Float = 14.5f, // 0.0 to 24.0
    val weather: WeatherCondition = WeatherCondition.CLEAR_SUNNY,
    val ambientTempCelsius: Float = 22f,
    val windSpeedKmh: Float = 12f,
    val roadFrictionMu: Float = 1.0f,
    val precipitationIntensity: Float = 0f
)

class EnvironmentController {
    var state = EnvironmentState()
    var timeSpeedMultiplier: Float = 1.0f // 1 second real = 1 second sim, or accelerated

    fun update(dt: Float) {
        // Advance time of day
        val newTime = (state.timeOfDayHours + (dt * timeSpeedMultiplier) / 3600f) % 24f
        state = state.copy(
            timeOfDayHours = newTime,
            roadFrictionMu = state.weather.surfaceType.frictionCoefficient,
            precipitationIntensity = if (state.weather.isRaining || state.weather.isSnowing) 0.7f else 0.0f
        )
    }

    fun setWeather(condition: WeatherCondition) {
        state = state.copy(
            weather = condition,
            roadFrictionMu = condition.surfaceType.frictionCoefficient,
            ambientTempCelsius = when (condition) {
                WeatherCondition.BLIZZARD_ICE -> -4f
                WeatherCondition.TORRENTIAL_DOWNPOUR, WeatherCondition.THUNDERSTORM -> 16f
                WeatherCondition.FOGGY_VALLEY -> 12f
                else -> 22f
            }
        )
    }

    fun isNight(): Boolean {
        return state.timeOfDayHours < 6.0f || state.timeOfDayHours > 20.0f
    }
}
