package com.example.bussim.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bussim.architecture.ArchitectureBlueprintData
import com.example.bussim.architecture.ArchitectureFile
import com.example.bussim.physics.PacejkaTireModel
import com.example.bussim.viewmodel.BusSimulatorViewModel
import com.example.bussim.viewmodel.SimulatorUiState

@Composable
fun ArchitectureExplorerScreen(
    viewModel: BusSimulatorViewModel,
    state: SimulatorUiState,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentFile = state.selectedArchFile

    var testSteer by remember { mutableFloatStateOf(0.15f) }
    var testThrottle by remember { mutableFloatStateOf(0.70f) }
    var testSurfaceMu by remember { mutableFloatStateOf(1.0f) }

    // Live Pacejka calculation for sandbox
    val normalLoadN = 45000f
    val b = 10.0f
    val c = 1.30f
    val d = testSurfaceMu * normalLoadN
    val e = -0.95f
    val slipRad = testSteer * 0.65f
    val fyCalc = PacejkaTireModel.magicFormula(slipRad, b, c, d, e)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp)
            .testTag("arch_explorer_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Header & Architecture Overview
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101722)),
                border = BorderStroke(1.dp, Color(0xFF233247)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Science, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "NEXT-GEN HEAVY VEHICLE ARCHITECTURE",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00E5FF)
                        )
                    }
                    Text(
                        text = "Production C++20 / C# game engine physics modules, Pacejka '02 Magic Formula, dual pneumatic air circuits, and ECAS leveling.",
                        fontSize = 11.sp,
                        color = Color(0xFF90A4AE)
                    )
                }
            }
        }

        // 2. Interactive Physics Step & Math Sandbox
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141C28)),
                border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LIVE PHYSICS TICK EXPERIMENTER",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFB300)
                        )
                        Surface(
                            color = Color(0xFF1F2B3E),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "dt = 16.6ms (60Hz)",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF00E5FF),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Sliders for dynamic inspection
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Wheel Slip Angle: ${"%.2f".format(slipRad)} rad", fontSize = 11.sp, color = Color.White)
                            Text(text = "Road Mu: ${"%.2f".format(testSurfaceMu)}", fontSize = 11.sp, color = Color(0xFF00E676))
                        }
                        Slider(
                            value = testSteer,
                            onValueChange = { testSteer = it },
                            valueRange = -0.5f..0.5f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF00E5FF),
                                activeTrackColor = Color(0xFF00E5FF)
                            )
                        )
                    }

                    // Live calculated telemetry box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0A0F16))
                            .border(1.dp, Color(0xFF1F2E42), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Pacejka Lateral Force Fy: ${"%.0f".format(fyCalc)} N",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF00E5FF)
                            )
                            Text(
                                text = "Peak Grip Capacity (D = μ·Fz): ${"%.0f".format(d)} N",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFFFFB300)
                            )
                            Text(
                                text = "Air Bag Load: ${(normalLoadN / 9.81f).toInt()} kg • Nominal Bellow Pressure: 7.5 bar",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF90A4AE)
                            )
                        }
                    }
                }
            }
        }

        // 3. Module File Selector Carousel
        item {
            Text(
                text = "ENGINE BLUEPRINTS & SOURCE MODULES",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF90A4AE)
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp)
            ) {
                items(ArchitectureBlueprintData.files) { file ->
                    val isSelected = file.id == currentFile.id
                    Surface(
                        onClick = { viewModel.selectArchFile(file) },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) Color(0xFF1E3247) else Color(0xFF131B26),
                        border = BorderStroke(1.dp, if (isSelected) Color(0xFF00E5FF) else Color(0xFF253448)),
                        modifier = Modifier.height(42.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp)
                        ) {
                            Text(
                                text = "[${file.language}]",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color(0xFF00E5FF) else Color(0xFFFFB300)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = file.title,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else Color(0xFF90A4AE)
                            )
                        }
                    }
                }
            }
        }

        // 4. Source Code Inspector Card
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF080C11)),
                border = BorderStroke(1.dp, Color(0xFF1E2838)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = currentFile.title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "${currentFile.category} • ${currentFile.language}",
                                fontSize = 10.sp,
                                color = Color(0xFF00E5FF)
                            )
                        }

                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Source Code", currentFile.sourceCode)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Copied ${currentFile.title} to clipboard", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Code", tint = Color(0xFF00E5FF))
                        }
                    }

                    Text(
                        text = currentFile.description,
                        fontSize = 11.sp,
                        color = Color(0xFF90A4AE)
                    )

                    // Code Viewer Box
                    val scrollState = rememberScrollState()
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(340.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF05070A))
                            .border(1.dp, Color(0xFF1A2330), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                            .horizontalScroll(scrollState)
                    ) {
                        Text(
                            text = currentFile.sourceCode,
                            color = Color(0xFFECEFF1),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
