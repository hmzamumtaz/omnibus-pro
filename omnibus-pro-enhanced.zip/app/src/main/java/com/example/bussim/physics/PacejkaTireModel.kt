package com.example.bussim.physics

import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Pacejka '89 / '02 Magic Formula Tire Friction Model
 * Computes longitudinal (Fx) and lateral (Fy) forces based on tire slip and road surface conditions.
 */
object PacejkaTireModel {

    enum class SurfaceType(val frictionCoefficient: Float, val displayName: String) {
        DRY_ASPHALT(1.0f, "Dry Asphalt"),
        WET_TAR(0.65f, "Wet Tar"),
        SNOW(0.35f, "Packed Snow"),
        BLACK_ICE(0.12f, "Black Ice"),
        GRAVEL(0.50f, "Loose Gravel")
    }

    data class TireState(
        val pressurePsi: Float = 115f, // Commercial bus high-pressure tire
        val treadDepthMm: Float = 14f,
        val temperatureCelsius: Float = 45f,
        val isBlownOut: Boolean = false,
        val slipAngleDeg: Float = 0f,
        val slipRatio: Float = 0f,
        val isHydroplaning: Boolean = false,
        val lateralForceN: Float = 0f,
        val longitudinalForceN: Float = 0f
    )

    /**
     * Classic Pacejka Magic Formula curve
     * y = D * sin(C * atan(B*x - E*(B*x - atan(B*x))))
     * B = Stiffness factor
     * C = Shape factor
     * D = Peak value (mu * Fz)
     * E = Curvature factor
     */
    fun magicFormula(x: Float, b: Float, c: Float, d: Float, e: Float): Float {
        val bx = b * x
        val arg = bx - e * (bx - atan(bx))
        return d * sin(c * atan(arg))
    }

    /**
     * Compute lateral force Fy given slip angle in radians and normal load Fz in Newtons
     */
    fun calculateLateralForce(
        slipAngleRad: Float,
        normalLoadFzN: Float,
        surface: SurfaceType,
        waterDepthMm: Float,
        speedKmh: Float,
        tire: TireState
    ): Pair<Float, Boolean> {
        if (tire.isBlownOut) {
            return Pair(0.05f * normalLoadFzN * sin(slipAngleRad), false)
        }

        // Hydroplaning threshold calculation (Horne's Formula for heavy vehicles):
        // Critical speed V_h (km/h) = 6.35 * sqrt(p_psi)
        val hydroplaneCritSpeed = 6.35f * sqrt(tire.pressurePsi)
        val isHydroplaning = waterDepthMm > 1.8f && speedKmh > hydroplaneCritSpeed && tire.treadDepthMm < 8f

        val effectiveMu = if (isHydroplaning) {
            0.08f // Severe loss of grip
        } else {
            surface.frictionCoefficient * (0.85f + 0.15f * (tire.treadDepthMm / 14f))
        }

        // Heavy-duty commercial tire Pacejka parameters
        val b = 10.0f // Stiffness
        val c = 1.30f // Shape
        val d = effectiveMu * normalLoadFzN // Peak lateral friction
        val e = -0.95f // Curvature

        val fy = magicFormula(slipAngleRad, b, c, d, e)
        return Pair(fy, isHydroplaning)
    }

    /**
     * Compute longitudinal force Fx given slip ratio kappa (-1.0 braking lockup, +1.0 wheel spin)
     */
    fun calculateLongitudinalForce(
        slipRatio: Float,
        normalLoadFzN: Float,
        surface: SurfaceType,
        isHydroplaning: Boolean
    ): Float {
        val effectiveMu = if (isHydroplaning) 0.09f else surface.frictionCoefficient
        val b = 12.0f
        val c = 1.65f
        val d = effectiveMu * normalLoadFzN
        val e = -0.50f

        return magicFormula(slipRatio, b, c, d, e)
    }
}
