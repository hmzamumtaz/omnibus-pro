package com.example.bussim.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BusDao {
    @Query("SELECT * FROM bus_fleet ORDER BY id ASC")
    fun getAllBuses(): Flow<List<BusFleetEntity>>

    @Query("SELECT * FROM bus_fleet WHERE isSelected = 1 LIMIT 1")
    fun getSelectedBus(): Flow<BusFleetEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBus(bus: BusFleetEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBuses(buses: List<BusFleetEntity>)

    @Update
    suspend fun updateBus(bus: BusFleetEntity)

    @Query("UPDATE bus_fleet SET isSelected = 0")
    suspend fun clearSelectedBuses()

    @Query("UPDATE bus_fleet SET isSelected = 1 WHERE id = :busId")
    suspend fun setSelectedBus(busId: String)

    @Query("SELECT * FROM route_history ORDER BY timestamp DESC")
    fun getAllRouteHistories(): Flow<List<RouteHistoryEntity>>

    @Insert
    suspend fun insertRouteHistory(history: RouteHistoryEntity)

    @Query("SELECT COUNT(*) FROM bus_fleet")
    suspend fun getBusCount(): Int
}
