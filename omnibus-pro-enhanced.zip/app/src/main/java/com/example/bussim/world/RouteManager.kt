package com.example.bussim.world

data class BusStop(
    val id: String,
    val name: String,
    val distanceMarkerMeters: Float,
    val waitingPassengers: Int,
    val alightingPassengers: Int,
    var isCompleted: Boolean = false
)

data class RouteDefinition(
    val routeId: String,
    val routeNumber: String,
    val title: String,
    val biome: String,
    val totalDistanceMeters: Float,
    val baseFarePerPassenger: Double,
    val stops: List<BusStop>
)

class RouteManager {
    val routes = listOf(
        RouteDefinition(
            routeId = "RT-42",
            routeNumber = "M42",
            title = "Metropolitan Transit Line 42",
            biome = "Urban Core & Harbor Expressway",
            totalDistanceMeters = 2400f,
            baseFarePerPassenger = 2.75,
            stops = listOf(
                BusStop("ST-1", "Central Metro Station", 150f, waitingPassengers = 12, alightingPassengers = 0),
                BusStop("ST-2", "Grand Avenue Plaza", 650f, waitingPassengers = 8, alightingPassengers = 4),
                BusStop("ST-3", "Financial District Tower", 1200f, waitingPassengers = 15, alightingPassengers = 6),
                BusStop("ST-4", "Civic Art Museum", 1750f, waitingPassengers = 6, alightingPassengers = 7),
                BusStop("ST-5", "Ocean Waterfront Terminal", 2350f, waitingPassengers = 0, alightingPassengers = 18)
            )
        ),
        RouteDefinition(
            routeId = "RT-ALPINE",
            routeNumber = "EXP-9",
            title = "Alpine Serpentine Pass",
            biome = "Mountain Switchbacks & Glacial Tunnel",
            totalDistanceMeters = 3800f,
            baseFarePerPassenger = 6.50,
            stops = listOf(
                BusStop("ALP-1", "Valley Base Depot", 200f, waitingPassengers = 18, alightingPassengers = 0),
                BusStop("ALP-2", "Pine Ridge Overlook", 1400f, waitingPassengers = 7, alightingPassengers = 5),
                BusStop("ALP-3", "Summit Ski Chalet", 2700f, waitingPassengers = 10, alightingPassengers = 12),
                BusStop("ALP-4", "Glacier Pass Terminal", 3700f, waitingPassengers = 0, alightingPassengers = 18)
            )
        ),
        RouteDefinition(
            routeId = "RT-COASTAL",
            routeNumber = "101",
            title = "Pacific Coastal Highway 101",
            biome = "Scenic Coastal Highway & Suspension Bridge",
            totalDistanceMeters = 4500f,
            baseFarePerPassenger = 4.25,
            stops = listOf(
                BusStop("CST-1", "Silicon Tech Park", 250f, waitingPassengers = 22, alightingPassengers = 0),
                BusStop("CST-2", "Lighthouse Cove", 1800f, waitingPassengers = 9, alightingPassengers = 8),
                BusStop("CST-3", "Harbor Point Marina", 3200f, waitingPassengers = 11, alightingPassengers = 10),
                BusStop("CST-4", "South Beach Interchange", 4400f, waitingPassengers = 0, alightingPassengers = 24)
            )
        )
    )

    var currentRouteIndex: Int = 0
    val activeRoute: RouteDefinition
        get() = routes[currentRouteIndex]

    var currentStopIndex: Int = 0

    val nextStop: BusStop?
        get() = if (currentStopIndex < activeRoute.stops.size) activeRoute.stops[currentStopIndex] else null

    fun getDistanceToNextStop(currentDistanceM: Float): Float {
        val stop = nextStop ?: return 0f
        return stop.distanceMarkerMeters - currentDistanceM
    }

    fun isAtStop(currentDistanceM: Float, speedKmh: Float): Boolean {
        val stop = nextStop ?: return false
        val dist = stop.distanceMarkerMeters - currentDistanceM
        return dist in -12f..18f && speedKmh < 3f
    }

    fun markStopCompleted(): BusStop? {
        val stop = nextStop
        if (stop != null) {
            stop.isCompleted = true
            currentStopIndex++
        }
        return stop
    }

    fun selectRoute(index: Int) {
        currentRouteIndex = index.coerceIn(0, routes.size - 1)
        currentStopIndex = 0
        activeRoute.stops.forEach { it.isCompleted = false }
    }
}
