package com.example.bussim.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bussim.viewmodel.BusSimulatorViewModel
import com.example.bussim.viewmodel.SimulatorUiState

import androidx.compose.material.icons.filled.Science

enum class AppTab(val label: String, val icon: ImageVector) {
    DRIVE("Drive", Icons.Default.DirectionsBus),
    WORLD("World", Icons.Default.Public),
    PHYSICS("Physics & Dyno", Icons.Default.Science),
    ROUTES("Routes & AI", Icons.Default.Map),
    GARAGE("Garage", Icons.Default.Tune),
    ARCHITECTURE("Architecture", Icons.Default.Code)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: BusSimulatorViewModel) {
    val state by viewModel.uiState.collectAsState()
    var currentTab by remember { mutableStateOf(AppTab.DRIVE) }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth > 680.dp

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "OMNIBUS PRO",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.sp,
                                color = Color(0xFF00E5FF)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = Color(0xFF1E2B3E),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "60Hz REALTIME",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF00E676),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    },
                    actions = {
                        // Quick Status Pill
                        Surface(
                            color = Color(0xFF141D28),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.padding(end = 12.dp)
                        ) {
                            Text(
                                text = "${state.weather.displayName} • ${"%.1f".format(state.timeOfDayHours)}h",
                                color = Color(0xFFFFB300),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF0A0E14),
                        titleContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                if (!isWideScreen) {
                    NavigationBar(
                        containerColor = Color(0xFF0E141E),
                        modifier = Modifier.testTag("bottom_nav_bar")
                    ) {
                        AppTab.values().forEach { tab ->
                            val isSelected = currentTab == tab
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { currentTab = tab },
                                icon = {
                                    Icon(
                                        tab.icon,
                                        contentDescription = tab.label,
                                        modifier = Modifier.size(20.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = Color(0xFF00E5FF),
                                    indicatorColor = Color(0xFF00E5FF),
                                    unselectedIconColor = Color(0xFF90A4AE),
                                    unselectedTextColor = Color(0xFF90A4AE)
                                ),
                                modifier = Modifier.testTag("tab_${tab.name.lowercase()}")
                            )
                        }
                    }
                }
            }
        ) { paddingValues ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(Color(0xFF070B10))
            ) {
                if (isWideScreen) {
                    NavigationRail(
                        containerColor = Color(0xFF0E141E),
                        modifier = Modifier.testTag("navigation_rail")
                    ) {
                        Spacer(modifier = Modifier.height(16.dp))
                        AppTab.values().forEach { tab ->
                            val isSelected = currentTab == tab
                            NavigationRailItem(
                                selected = isSelected,
                                onClick = { currentTab = tab },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label, fontSize = 10.sp) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = Color(0xFF00E5FF),
                                    indicatorColor = Color(0xFF00E5FF),
                                    unselectedIconColor = Color(0xFF90A4AE),
                                    unselectedTextColor = Color(0xFF90A4AE)
                                )
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Transient System Notification Toast Banner
                        AnimatedVisibility(
                            visible = state.eventNotification != null,
                            enter = fadeIn(),
                            exit = fadeOut()
                        ) {
                            state.eventNotification?.let { msg ->
                                Surface(
                                    color = if (msg.contains("WARNING") || msg.contains("CAUTION")) Color(0xFFB71C1C) else Color(0xFF00695C),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Notifications, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = msg,
                                            fontSize = 11.sp,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        // Tab Content
                        when (currentTab) {
                            AppTab.DRIVE -> {
                                val scrollState = rememberScrollState()
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(scrollState)
                                        .padding(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    CockpitVisualizerCanvas(state = state)
                                    CockpitControls(viewModel = viewModel, state = state)
                                }
                            }
                            AppTab.WORLD -> {
                                WorldDriveScreen(viewModel = viewModel, state = state)
                            }
                            AppTab.PHYSICS -> {
                                PhysicsDynoLabScreen(viewModel = viewModel, state = state)
                            }
                            AppTab.ROUTES -> {
                                RoutesAndPassengerScreen(viewModel = viewModel, state = state)
                            }
                            AppTab.GARAGE -> {
                                GarageCustomizationScreen(viewModel = viewModel, state = state)
                            }
                            AppTab.ARCHITECTURE -> {
                                ArchitectureExplorerScreen(viewModel = viewModel, state = state)
                            }
                        }
                    }
                }
            }
        }
    }
}
