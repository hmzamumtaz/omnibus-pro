package com.example.bussim.world

data class TrafficVehicle(
    val id: Int,
    val type: String, // Sedan, SUV, HeavyTruck, Taxi, DeliveryVan
    var relativeDistanceM: Float, // Distance relative to player bus
    var laneIndex: Int, // -1: Left lane, 0: Player lane, 1: Right lane
    var targetSpeedKmh: Float,
    var currentSpeedKmh: Float,
    var isBraking: Boolean = false,
    val colorHex: String
)

class TrafficSimulation {
    val vehicles = mutableListOf(
        TrafficVehicle(1, "Taxi", 45f, 0, 48f, 48f, false, "#FFD600"),
        TrafficVehicle(2, "Sedan", 110f, 1, 62f, 62f, false, "#00E5FF"),
        TrafficVehicle(3, "HeavyTruck", 185f, 0, 52f, 52f, false, "#90A4AE"),
        TrafficVehicle(4, "SUV", -35f, -1, 70f, 70f, false, "#E53935"),
        TrafficVehicle(5, "DeliveryVan", 260f, 1, 55f, 55f, false, "#FFFFFF")
    )

    fun update(dt: Float, playerSpeedKmh: Float) {
        val playerSpeedMs = playerSpeedKmh / 3.6f

        vehicles.forEach { v ->
            val vSpeedMs = v.currentSpeedKmh / 3.6f
            // Relative movement
            val deltaDist = (vSpeedMs - playerSpeedMs) * dt
            v.relativeDistanceM += deltaDist

            // AI behavior in player's lane
            if (v.laneIndex == 0 && v.relativeDistanceM in 10f..40f && playerSpeedKmh > v.currentSpeedKmh) {
                // If player is tailgating, AI accelerates or changes lane
                v.currentSpeedKmh += 3f * dt
                if (v.relativeDistanceM < 16f) {
                    v.laneIndex = if (v.id % 2 == 0) 1 else -1
                }
            }

            // Loop traffic when too far ahead or behind
            if (v.relativeDistanceM > 400f) {
                v.relativeDistanceM = -60f
                v.currentSpeedKmh = playerSpeedKmh + 10f
            } else if (v.relativeDistanceM < -120f) {
                v.relativeDistanceM = 320f
                v.currentSpeedKmh = (45f + (v.id * 5) % 25)
            }
        }
    }
}
