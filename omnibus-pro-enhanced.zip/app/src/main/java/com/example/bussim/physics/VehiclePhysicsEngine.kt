package com.example.bussim.physics

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

enum class VehicleCategory(val displayName: String) {
    TRANSIT_BUS("Urban Transit Bus"),
    HEAVY_TRUCK_SEMI("Heavy Semi-Truck 6x4 (40t GCW)")
}

data class VehicleTelemetry(
    val speedKmh: Float = 0f,
    val speedMs: Float = 0f,
    val engineRpm: Float = 600f,
    val engineHorsepower: Float = 0f,
    val engineTorqueNm: Float = 0f,
    val turboBoostBar: Float = 0f,
    val currentGear: Int = 1,
    val gearMode: String = "D",
    val longitudinalG: Float = 0f,
    val lateralG: Float = 0f,
    val jerkMs3: Float = 0f,
    val bodyRollDeg: Float = 0f,
    val bodyPitchDeg: Float = 0f,
    val frameTwistDeg: Float = 0f,
    val tank1PressureBar: Float = 10.2f,
    val tank2PressureBar: Float = 10.2f,
    val trailerTankPressureBar: Float = 10.0f,
    val retarderLevel: Int = 0,
    val jakeBrakeStage: Int = 0,
    val parkingBrake: Boolean = true,
    val trailerSupplyValvePopped: Boolean = true,
    val isKneeling: Boolean = false,
    val door1Open: Boolean = false,
    val door2Open: Boolean = false,
    val fuelOrBatteryPercent: Float = 90f,
    val totalWeightKg: Float = 19500f,
    val tireGripPercent: Float = 98f,
    val isHydroplaning: Boolean = false,
    val isAbsActive: Boolean = false,
    val brakeRotorTempC: Float = 45f,
    val brakeFadePercent: Float = 0f,
    val passengerComfortScore: Float = 100f,
    val distanceDrivenMeters: Float = 0f,
    val vehicleCategory: VehicleCategory = VehicleCategory.TRANSIT_BUS,
    val trailerArticulationDeg: Float = 0f,
    val isJackknifed: Boolean = false,
    val cabinTempC: Float = 21.5f,
    val acActive: Boolean = true,
    val sunBlindPosition: Float = 0.2f,
    val isDiffLocked: Boolean = false
)

class VehiclePhysicsEngine {
    val suspension = AirSuspensionModel()
    val drivetrain = DrivetrainModel()
    val brakes = PneumaticBrakeModel()

    var vehicleCategory: VehicleCategory = VehicleCategory.TRANSIT_BUS

    // Bus / Truck physical dimensions
    var emptyMassKg: Float = 14500f
    var passengerCount: Int = 0
    val avgPassengerWeightKg: Float = 75f
    var cargoLoadKg: Float = 0f // Heavy freight on semi-trailer

    val frontalAreaM2: Float
        get() = if (vehicleCategory == VehicleCategory.HEAVY_TRUCK_SEMI) 9.2f else 7.8f

    val dragCoefficient: Float
        get() = if (vehicleCategory == VehicleCategory.HEAVY_TRUCK_SEMI) 0.72f else 0.62f

    val airDensity: Float = 1.225f
    val rollingResistanceCoeff: Float = 0.012f
    val wheelRadiusM: Float = 0.505f

    // Dynamic motion state
    var speedMs: Float = 0f
    var steerAngleRad: Float = 0f
    var headingRad: Float = 0f
    var posX: Float = 0f
    var posY: Float = 0f
    var distanceDrivenM: Float = 0f

    // Truck 5th Wheel Trailer Articulation
    var trailerHeadingRad: Float = 0f
    var trailerArticulationDeg: Float = 0f
    var isJackknifed: Boolean = false

    // Frame Torsional Twist
    var frameTwistDeg: Float = 0f

    // Comfort & Jerk
    var previousAccelLongMs2: Float = 0f
    var currentAccelLongMs2: Float = 0f
    var currentAccelLatMs2: Float = 0f
    var currentJerkMs3: Float = 0f
    var comfortScore: Float = 98f

    // Controls & Interlocks
    var door1Open: Boolean = false
    var door2Open: Boolean = false
    var wipersActive: Boolean = false
    var wiperSpeed: Int = 0
    var headlightsOn: Boolean = false
    var highBeamOn: Boolean = false
    var hazardLightsOn: Boolean = false

    // HVAC Climate Control & Cab Accessories
    var cabinTempC: Float = 21.5f
    var acActive: Boolean = true
    var sunBlindPosition: Float = 0.2f // 0 = fully open, 1 = fully pulled down

    // Road surface
    var currentSurface: PacejkaTireModel.SurfaceType = PacejkaTireModel.SurfaceType.DRY_ASPHALT
    var waterDepthMm: Float = 0f
    var roadSlopeDeg: Float = 0f

    var frontTire = PacejkaTireModel.TireState()
    var rearTire = PacejkaTireModel.TireState()

    fun updateTick(
        dt: Float,
        throttleInput: Float,
        brakePedalInput: Float,
        steeringWheelNormalized: Float
    ): VehicleTelemetry {
        val totalMassKg = if (vehicleCategory == VehicleCategory.HEAVY_TRUCK_SEMI) {
            emptyMassKg + cargoLoadKg.coerceAtLeast(18000f) // 40t loaded semi
        } else {
            emptyMassKg + (passengerCount * avgPassengerWeightKg)
        }

        // Interlock: doors open or bus kneeling cuts throttle on transit buses
        val interlockCut = (vehicleCategory == VehicleCategory.TRANSIT_BUS) && (door1Open || door2Open || suspension.isKneeling)
        val safeThrottle = if (interlockCut) 0f else throttleInput.coerceIn(0f, 1f)

        // Steering angle mapping
        val maxSteer = if (vehicleCategory == VehicleCategory.HEAVY_TRUCK_SEMI) 0.55f else 0.65f
        val targetSteer = steeringWheelNormalized.coerceIn(-1f, 1f) * maxSteer
        steerAngleRad += (targetSteer - steerAngleRad) * min(1f, dt * 10f)

        // Engine & Transmission update
        val speedKmh = speedMs * 3.6f
        drivetrain.updateTransmission(speedKmh, safeThrottle, brakePedalInput, dt)
        val engineTorque = drivetrain.calculateTorque(safeThrottle, dt)
        val engineHp = drivetrain.calculateHorsepower(engineTorque, drivetrain.engineRpm)
        val driveTorqueAtWheels = drivetrain.getWheelTorque(engineTorque)

        // Brakes & Retarder update
        val wheelSlip = if (speedMs > 1f) ((speedMs - (speedMs * (1f - brakePedalInput * 0.2f))) / speedMs) else 0f
        val brakingTorque = brakes.update(dt, brakePedalInput, drivetrain.engineRpm, drivetrain.isEngineRunning, -wheelSlip)

        // Net wheel force
        val driveForceN = driveTorqueAtWheels / wheelRadiusM
        val brakeForceN = (brakingTorque / wheelRadiusM) * (if (speedMs > 0.05f) -1f else if (speedMs < -0.05f) 1f else 0f)

        // Environmental resistance forces
        val aerodragForceN = 0.5f * airDensity * dragCoefficient * frontalAreaM2 * speedMs * abs(speedMs)
        val rollingResistanceN = rollingResistanceCoeff * totalMassKg * 9.81f * (if (speedMs > 0.05f) 1f else if (speedMs < -0.05f) -1f else 0f)
        val slopeGravityForceN = totalMassKg * 9.81f * sin(Math.toRadians(roadSlopeDeg.toDouble())).toFloat()

        // Tire grip calculations
        val normalLoadFrontN = totalMassKg * 9.81f * (if (vehicleCategory == VehicleCategory.HEAVY_TRUCK_SEMI) 0.25f else 0.40f)
        val slipAngleFront = steerAngleRad - (if (abs(speedMs) > 0.5f) (currentAccelLatMs2 / (speedMs * 9.81f)) else 0f)
        val (lateralForceFrontN, frontHydro) = PacejkaTireModel.calculateLateralForce(
            slipAngleFront,
            normalLoadFrontN,
            currentSurface,
            waterDepthMm,
            speedKmh,
            frontTire
        )

        val netLongitudinalForceN = driveForceN + brakeForceN - aerodragForceN - rollingResistanceN - slopeGravityForceN

        // Longitudinal acceleration
        currentAccelLongMs2 = netLongitudinalForceN / totalMassKg
        val isParkBrakeLocked = brakes.parkingBrakeEngaged || brakes.trailerSupplyValvePopped

        if (isParkBrakeLocked && abs(speedMs) < 0.2f) {
            currentAccelLongMs2 = 0f
            speedMs = 0f
        } else {
            speedMs += currentAccelLongMs2 * dt
            if (abs(speedMs) < 0.05f && abs(safeThrottle) < 0.02f && brakePedalInput > 0.1f) {
                speedMs = 0f
            }
        }

        // Turning dynamics & Yaw rate
        val wheelbaseM = if (vehicleCategory == VehicleCategory.HEAVY_TRUCK_SEMI) 4.8f else 5.9f
        val yawRateRadS = (speedMs / wheelbaseM) * sin(steerAngleRad)
        headingRad += yawRateRadS * dt
        currentAccelLatMs2 = speedMs * yawRateRadS

        // Update positions
        posX += speedMs * cos(headingRad) * dt
        posY += speedMs * sin(headingRad) * dt
        distanceDrivenM += abs(speedMs * dt)

        // Semi-Trailer Kinematics around 5th wheel kingpin
        if (vehicleCategory == VehicleCategory.HEAVY_TRUCK_SEMI) {
            val trailerWheelbaseM = 9.2f
            val trailerYawRate = (speedMs / trailerWheelbaseM) * sin(headingRad - trailerHeadingRad)
            trailerHeadingRad += trailerYawRate * dt
            val diffRad = headingRad - trailerHeadingRad
            trailerArticulationDeg = Math.toDegrees(diffRad.toDouble()).toFloat()

            // Jackknife condition: articulation angle exceeds 45 degrees during heavy braking
            isJackknifed = abs(trailerArticulationDeg) > 42f && brakePedalInput > 0.4f
        } else {
            trailerArticulationDeg = 0f
            isJackknifed = false
        }

        // Suspension & Frame Torsion Dynamics
        suspension.update(
            dt,
            speedMs,
            currentAccelLongMs2,
            currentAccelLatMs2,
            totalMassKg,
            brakePedalInput > 0.2f
        )

        // Frame twist under torsional moment: theta = tau / K_torsion
        val rollMoment = totalMassKg * currentAccelLatMs2 * 1.15f
        frameTwistDeg = (rollMoment / 65000f).coerceIn(-4.5f, 4.5f)

        // Jerk calculation (comfort index)
        currentJerkMs3 = if (dt > 0.0001f) (currentAccelLongMs2 - previousAccelLongMs2) / dt else 0f
        previousAccelLongMs2 = currentAccelLongMs2

        // Comfort penalization
        if (abs(currentJerkMs3) > 2.8f || abs(currentAccelLatMs2) > 3.5f) {
            comfortScore = max(30f, comfortScore - 0.45f)
        } else {
            comfortScore = min(100f, comfortScore + 0.05f)
        }

        // Climate Control / Cabin Temperature Simulation
        val ambientTarget = if (acActive) 21.5f else 27.0f
        cabinTempC += (ambientTarget - cabinTempC) * (dt * 0.04f)
        val tempDiscomfort = abs(cabinTempC - 21.5f)
        if (tempDiscomfort > 3.5f) {
            comfortScore = max(20f, comfortScore - 0.02f)
        }

        // Fuel & Battery consumption
        if (drivetrain.isEngineRunning && drivetrain.gearMode != "P") {
            val acExtra = if (acActive) 1.15f else 1.0f
            drivetrain.fuelTankPercent = max(0f, drivetrain.fuelTankPercent - (0.0008f * dt * acExtra * (drivetrain.engineRpm / 1500f)))
            drivetrain.batterySocPercent = max(0f, drivetrain.batterySocPercent - (0.001f * dt * acExtra))
        }

        return VehicleTelemetry(
            speedKmh = speedMs * 3.6f,
            speedMs = speedMs,
            engineRpm = drivetrain.engineRpm,
            engineHorsepower = engineHp,
            engineTorqueNm = engineTorque,
            turboBoostBar = drivetrain.turboBoostBar,
            currentGear = drivetrain.currentGear,
            gearMode = drivetrain.gearMode,
            longitudinalG = currentAccelLongMs2 / 9.81f,
            lateralG = currentAccelLatMs2 / 9.81f,
            jerkMs3 = currentJerkMs3,
            bodyRollDeg = suspension.bodyRollAngleDeg,
            bodyPitchDeg = suspension.bodyPitchAngleDeg,
            frameTwistDeg = frameTwistDeg,
            tank1PressureBar = brakes.tank1PressureBar,
            tank2PressureBar = brakes.tank2PressureBar,
            trailerTankPressureBar = brakes.trailerTankPressureBar,
            retarderLevel = brakes.retarderLevel,
            jakeBrakeStage = brakes.jakeBrakeStage,
            parkingBrake = brakes.parkingBrakeEngaged,
            trailerSupplyValvePopped = brakes.trailerSupplyValvePopped,
            isKneeling = suspension.isKneeling,
            door1Open = door1Open,
            door2Open = door2Open,
            fuelOrBatteryPercent = if (drivetrain.powertrainType == PowertrainType.ELECTRIC) drivetrain.batterySocPercent else drivetrain.fuelTankPercent,
            totalWeightKg = totalMassKg,
            tireGripPercent = if (frontHydro) 15f else (currentSurface.frictionCoefficient * 100f),
            isHydroplaning = frontHydro,
            isAbsActive = brakes.isAbsActive,
            brakeRotorTempC = brakes.rotorTempCelsius,
            brakeFadePercent = (1.0f - brakes.brakeFadeFactor) * 100f,
            passengerComfortScore = comfortScore,
            distanceDrivenMeters = distanceDrivenM,
            vehicleCategory = vehicleCategory,
            trailerArticulationDeg = trailerArticulationDeg,
            isJackknifed = isJackknifed,
            cabinTempC = cabinTempC,
            acActive = acActive,
            sunBlindPosition = sunBlindPosition,
            isDiffLocked = drivetrain.isInterAxleDiffLocked
        )
    }

    fun toggleVehicleCategory(): VehicleCategory {
        vehicleCategory = if (vehicleCategory == VehicleCategory.TRANSIT_BUS) {
            VehicleCategory.HEAVY_TRUCK_SEMI
        } else {
            VehicleCategory.TRANSIT_BUS
        }
        if (vehicleCategory == VehicleCategory.HEAVY_TRUCK_SEMI) {
            drivetrain.powertrainType = PowertrainType.HEAVY_TRUCK_DIESEL
            drivetrain.transmissionType = TransmissionType.EATON_FULLER_18
            emptyMassKg = 8900f
            cargoLoadKg = 24000f
        } else {
            drivetrain.powertrainType = PowertrainType.DIESEL
            drivetrain.transmissionType = TransmissionType.AUTOMATIC_ZF
            emptyMassKg = 14500f
            cargoLoadKg = 0f
        }
        return vehicleCategory
    }

    fun toggleDoor1(): Boolean {
        door1Open = !door1Open
        return door1Open
    }

    fun toggleDoor2(): Boolean {
        door2Open = !door2Open
        return door2Open
    }

    fun toggleAc(): Boolean {
        acActive = !acActive
        return acActive
    }
}
