package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Heavy-duty vehicle & cockpit automotive palette
val CockpitCarbon = Color(0xFF0A0E14)
val CockpitDarkNavy = Color(0xFF101722)
val CockpitSurface = Color(0xFF16202E)
val CockpitSurfaceVariant = Color(0xFF1F2B3E)
val CockpitBorder = Color(0xFF2C3C54)

val GaugeCyan = Color(0xFF00E5FF)
val GaugeNeonGreen = Color(0xFF00E676)
val GaugeAmber = Color(0xFFFFB300)
val GaugeWarningRed = Color(0xFFFF3D00)
val GaugePurple = Color(0xFFB388FF)
val GaugeSteel = Color(0xFF90A4AE)

val IndicatorActive = Color(0xFF76FF03)
val MatrixLedAmber = Color(0xFFFF9100)
val MatrixLedBackground = Color(0xFF050505)

val TextPrimary = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
