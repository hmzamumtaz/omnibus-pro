package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val CockpitColorScheme = darkColorScheme(
    primary = GaugeCyan,
    onPrimary = Color.Black,
    primaryContainer = CockpitSurfaceVariant,
    onPrimaryContainer = GaugeCyan,
    secondary = GaugeAmber,
    onSecondary = Color.Black,
    secondaryContainer = CockpitSurfaceVariant,
    onSecondaryContainer = GaugeAmber,
    tertiary = GaugeNeonGreen,
    onTertiary = Color.Black,
    error = GaugeWarningRed,
    onError = Color.White,
    background = CockpitCarbon,
    onBackground = TextPrimary,
    surface = CockpitDarkNavy,
    onSurface = TextPrimary,
    surfaceVariant = CockpitSurface,
    onSurfaceVariant = TextSecondary,
    outline = CockpitBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to rich cockpit dark theme
    dynamicColor: Boolean = false, // Keep high-contrast cockpit styling
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CockpitColorScheme,
        typography = Typography,
        content = content
    )
}
