package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.bussim.physics.PacejkaTireModel
import com.example.bussim.physics.PneumaticBrakeModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("OmniBus Pro", appName)
    }

    @Test
    fun `pacejka magic formula calculates positive lateral force on slip`() {
        val normalLoad = 45000f
        val slipAngleRad = 0.10f // ~5.7 degrees
        val (fy, hydro) = PacejkaTireModel.calculateLateralForce(
            slipAngleRad = slipAngleRad,
            normalLoadFzN = normalLoad,
            surface = PacejkaTireModel.SurfaceType.DRY_ASPHALT,
            waterDepthMm = 0f,
            speedKmh = 45f,
            tire = PacejkaTireModel.TireState()
        )
        assertTrue("Lateral force should be positive for positive slip", fy > 1000f)
        assertTrue("Should not hydroplane on dry surface", !hydro)
    }

    @Test
    fun `pneumatic brake model engages maxi spring brake by default`() {
        val brakes = PneumaticBrakeModel()
        assertTrue("Spring brake must be engaged initially for safety", brakes.parkingBrakeEngaged)
        val torque = brakes.update(0.016f, 0f, 600f, true, 0f)
        assertTrue("Braking torque must exceed 30000 Nm when park brake locked", torque >= 30000f)
    }
}
