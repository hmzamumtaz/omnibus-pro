# Omnibus Pro — Bus Simulator

Omnibus Pro is an Android/Jetpack Compose bus-simulation project with a realtime vehicle model, passenger/traffic AI, garage progression, and a real-world road-routing mode.

## Added in this build

- Realtime vehicle physics loop at approximately 60 Hz.
- Diesel, electric, hybrid and CNG bus configurations.
- Expanded fleet with city buses, articulated buses and intercity coaches.
- Garage customization for livery/color, destination display and suspension setup.
- Dynamic weather, time of day, braking/retarder and pneumatic systems.
- Passenger boarding, ticket validation, comfort/satisfaction and stop requests.
- Traffic AI plus a dedicated pedestrian simulation layer.
- **World Drive** mode with selectable real cities and domestic/international routes.
- Live road routing through OSRM and interactive OpenStreetMap/Leaflet rendering.
- Route distance and road ETA reporting.
- World map overlays for player bus, traffic AI and pedestrians.
- Existing Room persistence for fleet and completed-route history.

## Important production notes

World routing and map tiles are online services. A production release should:
1. Use a properly provisioned routing backend (OSRM/GraphHopper/Valhalla) instead of relying on a public demo endpoint.
2. Follow OpenStreetMap tile usage and attribution requirements.
3. Add caching/offline map packages for long-haul routes.
4. Replace the current 2D world renderer with a dedicated 3D renderer/game engine (e.g. Unity or Unreal) if photorealistic driving, animated bus models, deformable traffic, and pedestrian animation are required.
5. Add licensed/owned 3D vehicle, environment and sound assets before commercial distribution.

## Open locally

Open the project directory in Android Studio and run the `app` configuration.
